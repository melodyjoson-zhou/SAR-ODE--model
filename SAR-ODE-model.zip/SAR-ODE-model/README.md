# SAR ODE Model — A Progressive ODE Model of Seasonal Allergic Rhinitis

A progressively extended ordinary differential equation (ODE) model of seasonal allergic rhinitis (SAR), evolving from a 10-dimensional core Th2/IgE/mast cell/eosinophil axis to a 21-dimensional system integrating TLR4/NF-κB innate immunity, Th17/Treg imbalance, and seasonal priming/tolerance dynamics.

## Repository Structure



## Requirements

- Python 3.11+
- See 

Install:


## Running the Scripts

Scripts should be run in order. Each script produces figures and/or CSV output files.

### Path Configuration

The scripts were developed in a specific environment and contain hardcoded paths:
-  or  — for importing model code
-  — for reading input data
- Output paths like 

**Before running, update these paths** to match your local directory structure:
- Model code: point to  in this repository
- Input data: point to  in this repository
- Output: point to your desired output directory

### Script Descriptions

#### 01_model_comparison.py
Compares the 10-dim core model with the 19-dim extended model. Generates Figures 5-8, Tables 4-5.

#### 02_calibration_validation.py
Parameter calibration against published cytokine data and clinical trial validation. Generates calibration results, Sobol sensitivity analysis, Figures 9-13.

#### 03_virtual_cohort_subtyping.py
Virtual cohort generation and AI-based patient subtyping. Generates 2,000-patient cohort, MLP surrogate model, K-means subtyping, Figures 9-11.

#### 04_revision_simulations.py
Reviewer-requested supplementary simulations: ablation analysis, drug-effect parametric sweep, Bliss synergy test, Sobol convergence check, non-negativity verification. Generates Supplementary Tables S17-S22.

#### 05_pca2_recompute.py
PCA-reduced K-means clustering (final subtype analysis): PC1+PC2 of six output metrics, K=3, silhouette=0.36, ARI=0.98. Generates subtype-specific drug responses and stability analysis.

## Model Overview

- **Core model (10-dim)**: Allergen → Alarmins → DC → Th2 → Cytokines → IgE → Mast cells → Mediators → Eosinophils → Symptoms
- **Extended model (19-dim)**: Adds TLR4/MyD88/NF-κB innate immunity pathway (5 variables) and Th17/IL-17/Treg/IL-10 regulatory axis (4 variables)
- **Seasonal extension (21-dim)**: Adds priming (P) and tolerance (T) dynamics for chronic 56-day simulation
- **Virtual cohort**: 2,000 simulated individuals with lognormal parameter variation (CV=30%)
- **Subtyping**: PCA-reduced K-means on 6 output metrics → 3 subtypes (40%/38%/22%)
- **Validation**: 11 published studies, 2 clinical trials, Sobol sensitivity, ablation analysis

## Citation

Zhang Q, Hu H, Yue Y, Qi W, Zhu W, Liu X, Zhou X. A Progressive ODE Model of Seasonal Allergic Rhinitis: From Core Th2 Axis to 21-Dimensional Multi-Pathway Integration with Seasonal Dynamics and Directional Assessment. *Frontiers in Immunology* (under revision).

## License

This code is provided for reproducibility of the published manuscript. All model parameters and calibration data are derived from the cited published literature.
