"""
SAR 19-Dimensional ODE Model v2
================================
Extended from the 10-dim core model with:
  - TLR4/MyD88/NF-κB innate immunity pathway (+5 variables)
  - Th17/Treg imbalance axis (+4 variables)

State variables (19 total):
  Core axis (10): A, Al, DC, Th2, Cyto, IgE, MC, Med, Eos, Sym
  TLR4 pathway (5): TLR4, MyD88, NFkB, ProInf, Neu
  Th17/Treg axis (4): Th17, IL17, Treg, IL10

Author: Biomni
"""

import numpy as np
from scipy.integrate import solve_ivp
import pandas as pd

# ---------------------------------------------------------------------------
# Default parameters — core axis (same as v1, with symptom equation modified)
# ---------------------------------------------------------------------------
DEFAULT_PARAMS = {
    # === Core axis (from v1) ===
    'k_A':       1.4,
    'k_Al1':     2.0, 'k_Al2': 1.0, 'Al_max': 500.0,
    'k_DC1':     0.5, 'k_DC2': 0.12, 'DC_max': 50.0,
    'k_T1':      0.3, 'k_T2': 0.06, 'Th2_max': 80.0,
    'k_C1':      8.0, 'k_C2': 0.7,
    'k_IgE0':    2.1, 'k_IgE1': 0.005, 'k_IgE2': 0.014,
    'k_MC1':     0.0008, 'k_MC2': 1.4,
    'k_Med1':    200.0, 'k_Med2': 4.0,
    'k_Eos1':    0.5, 'k_Eos2': 0.15, 'Eos_max': 200.0,
    # Symptom: k_S1 (mediator), k_S2 (eosinophil), k_S5 (resolution, renamed from k_S3)
    'k_S1':      0.4, 'k_S2': 0.015, 'k_S5': 0.5, 'Sym_max': 10.0,

    # === TLR4/MyD88/NF-κB pathway ===
    'k_TLR1':    1.5,    # /h, TLR4 activation by allergen
    'k_TLR2':    0.7,    # /h, TLR4 deactivation
    'k_MyD1':    3.0,    # /h, MyD88 recruitment
    'k_MyD2':    1.5,    # /h, MyD88 degradation
    'k_NF1':     2.5,    # /h, NF-κB activation
    'k_NF2':     1.0,    # /h, NF-κB inhibition (IκB feedback)
    'k_PI1':     15.0,   # pg/(mL·h), pro-inflammatory cytokine production
    'k_PI2':     0.5,    # /h, TNF-α degradation t1/2 ~ 1.4h
    'k_Neu1':    0.3,    # cells/(μL·h·pg/mL), neutrophil recruitment
    'k_Neu2':    0.2,    # /h, neutrophil apoptosis ~ 3.5h
    'Neu_max':   150.0,  # cells/μL

    # === Cross-connections: TLR4 → core axis ===
    'k_AlNF':    50.0,   # NF-κB → alarmin enhancement
    'k_DCNF':    0.2,    # NF-κB → DC enhancement

    # === Th17/Treg axis ===
    'k_Th17_1':  0.005,  # /h, Th17 differentiation (requires DC + IL-6/ProInf)
    'k_Th17_2':  0.04,   # /h, Th17 decay t1/2 ~ 17h
    'Th17_max':  30.0,   # cells/μL
    'k_IL17_1':  5.0,    # pg/(mL·h·cell), IL-17 production
    'k_IL17_2':  0.5,    # /h, IL-17 degradation t1/2 ~ 1.4h
    'k_Treg_1':  0.02,   # /h, Treg expansion
    'k_Treg_2':  0.02,   # /h, Treg decay (steady-state maintenance)
    'Treg_max':  20.0,   # cells/μL
    'k_IL10_1':  3.0,    # pg/(mL·h·cell), IL-10 production
    'k_IL10_2':  0.3,    # /h, IL-10 degradation t1/2 ~ 2.3h

    # === Cross-connections: Th17/Treg → core + TLR4 ===
    'k_Treg_inh':  0.01,   # /h, Treg suppresses Th17
    'k_Th17_inh':  0.005,  # /h, Th17 suppresses Treg
    'k_T1IL17':    0.002,  # /h, IL-17 enhances Th2
    'k_Neu1IL17':  0.1,    # cells/(μL·h·pg/mL), IL-17 recruits neutrophils
    'k_IL10_DC':   0.001,  # /h, IL-10 suppresses DC

    # === Symptom contributions from new pathways ===
    'k_S3b':     0.008,  # score/(cell·h), neutrophil → symptom
    'k_S4':      0.003,  # (score·mL)/(pg·h), pro-inflammatory → symptom
    'k_S_IL10':  0.01,   # (score·mL)/(pg·h), IL-10 suppresses symptom
}

# ---------------------------------------------------------------------------
# Initial conditions
# ---------------------------------------------------------------------------
DEFAULT_IC = {
    # Core axis
    'A':    100.0, 'Al': 0.0, 'DC': 5.0, 'Th2': 2.0, 'Cyto': 0.0,
    'IgE':  150.0, 'MC': 0.0, 'Med': 0.0, 'Eos': 10.0, 'Sym': 0.0,
    # TLR4 pathway
    'TLR4': 0.0, 'MyD88': 0.0, 'NFkB': 0.0, 'ProInf': 0.0, 'Neu': 5.0,
    # Th17/Treg axis
    'Th17': 1.0, 'IL17': 0.0, 'Treg': 5.0, 'IL10': 2.0,
}

STATE_NAMES = [
    'A', 'Al', 'DC', 'Th2', 'Cyto', 'IgE', 'MC', 'Med', 'Eos', 'Sym',
    'TLR4', 'MyD88', 'NFkB', 'ProInf', 'Neu',
    'Th17', 'IL17', 'Treg', 'IL10'
]

VAR_LABELS = {
    'A': 'Allergen (ng/mL)', 'Al': 'Alarmins (pg/mL)', 'DC': 'DC (cells/μL)',
    'Th2': 'Th2 (cells/μL)', 'Cyto': 'Cytokines (pg/mL)', 'IgE': 'IgE (ng/mL)',
    'MC': 'Mast Cells (fraction)', 'Med': 'Mediators (ng/mL)',
    'Eos': 'Eosinophils (cells/μL)', 'Sym': 'Symptom Score',
    'TLR4': 'TLR4 (fraction)', 'MyD88': 'MyD88 (fraction)',
    'NFkB': 'NF-κB (fraction)', 'ProInf': 'Pro-inflammatory (pg/mL)',
    'Neu': 'Neutrophils (cells/μL)',
    'Th17': 'Th17 (cells/μL)', 'IL17': 'IL-17 (pg/mL)',
    'Treg': 'Treg (cells/μL)', 'IL10': 'IL-10 (pg/mL)',
}


def ode_system_v2(t, y, params):
    """19-dimensional ODE system."""
    (A, Al, DC, Th2, Cyto, IgE, MC, Med, Eos, Sym,
     TLR4, MyD88, NFkB, ProInf, Neu,
     Th17, IL17, Treg, IL10) = y
    p = params

    # === Core axis (modified with cross-connections) ===
    dA = -p['k_A'] * A

    dAl = (p['k_Al1'] * A + p['k_AlNF'] * NFkB) * (1.0 - Al / p['Al_max']) - p['k_Al2'] * Al

    dDC = (p['k_DC1'] * Al + p['k_DCNF'] * NFkB) * (1.0 - DC / p['DC_max']) \
          - p['k_DC2'] * DC - p['k_IL10_DC'] * IL10 * DC

    dTh2 = (p['k_T1'] * DC + p['k_T1IL17'] * IL17) * (1.0 - Th2 / p['Th2_max']) - p['k_T2'] * Th2

    dCyto = p['k_C1'] * Th2 - p['k_C2'] * Cyto

    dIgE = p['k_IgE0'] + p['k_IgE1'] * Cyto - p['k_IgE2'] * IgE

    dMC = p['k_MC1'] * A * IgE * (1.0 - MC) - p['k_MC2'] * MC

    dMed = p['k_Med1'] * MC - p['k_Med2'] * Med

    dEos = p['k_Eos1'] * Cyto * (1.0 - Eos / p['Eos_max']) - p['k_Eos2'] * Eos

    dSym = (p['k_S1'] * Med + p['k_S2'] * Eos + p['k_S3b'] * Neu + p['k_S4'] * ProInf) \
           * (1.0 - Sym / p['Sym_max']) - p['k_S5'] * Sym - p['k_S_IL10'] * IL10

    # === TLR4/MyD88/NF-κB pathway ===
    dTLR4 = p['k_TLR1'] * A * (1.0 - TLR4) - p['k_TLR2'] * TLR4
    dMyD88 = p['k_MyD1'] * TLR4 * (1.0 - MyD88) - p['k_MyD2'] * MyD88
    dNFkB = p['k_NF1'] * MyD88 * (1.0 - NFkB) - p['k_NF2'] * NFkB
    dProInf = p['k_PI1'] * NFkB - p['k_PI2'] * ProInf
    dNeu = (p['k_Neu1'] * ProInf + p['k_Neu1IL17'] * IL17) * (1.0 - Neu / p['Neu_max']) \
           - p['k_Neu2'] * Neu

    # === Th17/Treg axis ===
    dTh17 = p['k_Th17_1'] * DC * ProInf * (1.0 - Th17 / p['Th17_max']) \
            - p['k_Th17_2'] * Th17 - p['k_Treg_inh'] * Treg
    dIL17 = p['k_IL17_1'] * Th17 - p['k_IL17_2'] * IL17
    dTreg = p['k_Treg_1'] * DC * (1.0 - Treg / p['Treg_max']) \
            - p['k_Treg_2'] * Treg - p['k_Th17_inh'] * Th17
    dIL10 = p['k_IL10_1'] * Treg - p['k_IL10_2'] * IL10

    return np.array([
        dA, dAl, dDC, dTh2, dCyto, dIgE, dMC, dMed, dEos, dSym,
        dTLR4, dMyD88, dNFkB, dProInf, dNeu,
        dTh17, dIL17, dTreg, dIL10
    ])


def solve_model_v2(params=None, ic=None, t_span=(0, 24), t_eval=None):
    """Solve the 19-dim SAR ODE model."""
    if params is None:
        params = DEFAULT_PARAMS.copy()
    if ic is None:
        ic = DEFAULT_IC.copy()
    if t_eval is None:
        t_eval = np.linspace(t_span[0], t_span[1], int((t_span[1] - t_span[0]) / 0.05) + 1)

    y0 = np.array([ic[name] for name in STATE_NAMES])

    result = solve_ivp(
        fun=lambda t, y: ode_system_v2(t, y, params),
        t_span=t_span, y0=y0, t_eval=t_eval,
        method='LSODA', rtol=1e-8, atol=1e-10,
    )
    if not result.success:
        raise RuntimeError(f"ODE integration failed: {result.message}")
    return result


def result_to_dataframe_v2(result):
    df = pd.DataFrame(result.y.T, columns=STATE_NAMES)
    df.insert(0, 'time_h', result.t)
    return df


def compute_metrics_v2(result):
    sym = result.y[9]
    t = result.t
    return {
        'Sym_max': float(np.max(sym)),
        't_peak_h': float(t[np.argmax(sym)]),
        'AUC_0_24h': float(np.trapz(sym, t)),
        'Eos_peak': float(np.max(result.y[8])),
        'Neu_peak': float(np.max(result.y[14])),
        'IL17_peak': float(np.max(result.y[16])),
        'ProInf_peak': float(np.max(result.y[13])),
        'Th17_peak': float(np.max(result.y[15])),
        'Treg_min': float(np.min(result.y[17])),
    }


# ---------------------------------------------------------------------------
# Drug interventions for v2 model
# ---------------------------------------------------------------------------
DRUG_INTERVENTIONS_V2 = {
    'Control': {},
    'Antihistamine (H1 blocker)': {'k_S1': DEFAULT_PARAMS['k_S1'] * 0.3},
    'Omalizumab (anti-IgE)': {
        '_ic_override': {'IgE': DEFAULT_IC['IgE'] * 0.3},
        'k_IgE0': DEFAULT_PARAMS['k_IgE0'] * 0.3,
    },
    'Dupilumab (anti-IL-4Rα)': {
        'k_C1': DEFAULT_PARAMS['k_C1'] * 0.2,
        'k_IgE1': DEFAULT_PARAMS['k_IgE1'] * 0.2,
    },
    'Tezepelumab (anti-TSLP)': {'k_Al1': DEFAULT_PARAMS['k_Al1'] * 0.2},
    # New targets
    'Anti-IL-17 (secukinumab)': {'k_IL17_1': DEFAULT_PARAMS['k_IL17_1'] * 0.1},
    'Anti-TLR4 (antagonist)': {'k_TLR1': DEFAULT_PARAMS['k_TLR1'] * 0.1},
    'Anti-TNF-α': {'k_PI1': DEFAULT_PARAMS['k_PI1'] * 0.2},
    'Treg enhancement (low-dose IL-2)': {
        'k_Treg_1': DEFAULT_PARAMS['k_Treg_1'] * 3.0,
        '_ic_override': {'Treg': DEFAULT_IC['Treg'] * 2.0},
    },
}


def solve_with_intervention_v2(intervention_name, t_span=(0, 24)):
    intervention = DRUG_INTERVENTIONS_V2[intervention_name]
    params = DEFAULT_PARAMS.copy()
    ic = DEFAULT_IC.copy()
    for key, val in intervention.items():
        if key == '_ic_override':
            ic.update(val)
        else:
            params[key] = val
    return solve_model_v2(params=params, ic=ic, t_span=t_span)


if __name__ == '__main__':
    res = solve_model_v2()
    metrics = compute_metrics_v2(res)
    print("19-dim model solved successfully.")
    print(f"Time points: {len(res.t)}")
    for k, v in metrics.items():
        print(f"  {k}: {v:.3f}")

    # Check key variables at several timepoints
    df = result_to_dataframe_v2(res)
    for t_check in [0.5, 1, 2, 4, 6, 8, 12, 24]:
        row = df.iloc[(df['time_h'] - t_check).abs().idxmin()]
        print(f"t={row['time_h']:.1f}: Sym={row['Sym']:.2f} TLR4={row['TLR4']:.3f} "
              f"NFkB={row['NFkB']:.3f} ProInf={row['ProInf']:.1f} Neu={row['Neu']:.1f} "
              f"Th17={row['Th17']:.2f} IL17={row['IL17']:.1f} Treg={row['Treg']:.2f} IL10={row['IL10']:.2f}")
