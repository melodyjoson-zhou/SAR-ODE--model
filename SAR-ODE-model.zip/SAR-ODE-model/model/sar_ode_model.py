"""
Seasonal Allergic Rhinitis (SAR) Core Pathway ODE Model
========================================================
10-dimensional ODE system modeling the core immunological cascade
of seasonal allergic rhinitis following a single acute pollen exposure
over 0-24 hours.

State variables:
  A    - Allergen concentration in nasal mucosa (ng/mL)
  Al   - Epithelial alarmins TSLP+IL-33 (pg/mL)
  DC   - Activated dendritic cells (cells/μL)
  Th2  - Activated Th2 cells (cells/μL)
  Cyto - Th2 cytokines IL-4/IL-5/IL-13 (pg/mL)
  IgE  - Allergen-specific IgE (ng/mL)
  MC   - Activated mast cells (degranulation fraction, 0-1)
  Med  - Inflammatory mediators histamine+leukotrienes (ng/mL)
  Eos  - Nasal mucosal eosinophils (cells/μL)
  Sym  - Symptom score (0-10)

Model exhibits biphasic response:
  - Immediate phase (0-2h): mediator-driven, Sym peaks ~7.0
  - Late phase (6-24h): eosinophil-driven, Sym plateaus ~3.4

Author: Biomni
"""

import numpy as np
from scipy.integrate import solve_ivp
import pandas as pd

# ---------------------------------------------------------------------------
# Default parameters (mixed strategy: literature-supported + estimated)
# ---------------------------------------------------------------------------
DEFAULT_PARAMS = {
    # Allergen clearance
    'k_A':       1.4,     # /h, mucociliary clearance t1/2 ~ 30 min [literature]

    # Alarmin (TSLP + IL-33) production & degradation
    'k_Al1':     2.0,     # /h, epithelial rapid response [estimated]
    'k_Al2':     1.0,     # /h, IL-33 t1/2 ~ 40 min [estimated]
    'Al_max':    500.0,   # pg/mL, local concentration ceiling [estimated]

    # Dendritic cell activation
    'k_DC1':     0.5,     # /h, DC activation by alarmins [estimated]
    'k_DC2':     0.12,    # /h, DC tissue half-life ~ 6 h [literature]
    'DC_max':    50.0,    # cells/μL, max activated DC [estimated]

    # Th2 activation
    'k_T1':      0.3,     # /h, Th2 activation by DC antigen presentation [estimated]
    'k_T2':      0.06,    # /h, effector Th2 t1/2 ~ 12 h [literature]
    'Th2_max':   80.0,    # cells/μL, max Th2 [estimated]

    # Cytokine production & degradation
    'k_C1':      8.0,     # pg/(mL·h·cell), Th2 cytokine production [estimated]
    'k_C2':      0.7,     # /h, IL-4 t1/2 ~ 60 min [literature]

    # IgE dynamics
    'k_IgE0':    2.1,     # ng/(mL·h), baseline IgE production [calculated: maintains IgE_ss=150]
    'k_IgE1':    0.005,   # /h, cytokine-driven IgE upregulation [estimated]
    'k_IgE2':    0.014,   # /h, IgE t1/2 ~ 2.5 days [literature]

    # Mast cell activation (with saturation to keep fraction 0-1)
    'k_MC1':     0.0008,  # /h, FcεRI cross-linking efficiency [estimated]
    'k_MC2':     1.4,     # /h, degranulation recovery ~ 30 min [literature]

    # Mediator release & clearance
    'k_Med1':    200.0,   # ng/(mL·h), mediator release rate [estimated]
    'k_Med2':    4.0,     # /h, histamine t1/2 ~ 10 min [literature]

    # Eosinophil recruitment & apoptosis (with carrying capacity)
    'k_Eos1':    0.5,     # cells/(μL·h·pg/mL), IL-5-driven recruitment [estimated]
    'k_Eos2':    0.15,    # /h, tissue survival ~ 5 h [literature-adjusted]
    'Eos_max':   200.0,   # cells/μL, max tissue eosinophil burden [estimated]

    # Symptom generation & resolution (with saturation to keep 0-10)
    'k_S1':      0.4,     # (score·mL)/(ng·h), mediator→symptom [calibrated]
    'k_S2':      0.015,   # score/(cell·h), eosinophil→symptom [calibrated]
    'k_S3':      0.5,     # /h, symptom resolution t1/2 ~ 1.4 h [estimated]
    'Sym_max':   10.0,    # max symptom score [fixed]
}

# ---------------------------------------------------------------------------
# Initial conditions
# ---------------------------------------------------------------------------
DEFAULT_IC = {
    'A':    100.0,   # ng/mL, single pollen exposure bolus
    'Al':   0.0,     # pg/mL, no damage before exposure
    'DC':   5.0,     # cells/μL, baseline DC present
    'Th2':  2.0,     # cells/μL, memory Th2 (sensitized individual)
    'Cyto': 0.0,     # pg/mL, no acute inflammation
    'IgE':  150.0,   # ng/mL, pre-existing IgE (sensitized)
    'MC':   0.0,     # fraction, not activated
    'Med':  0.0,     # ng/mL, not released
    'Eos':  10.0,    # cells/μL, baseline few
    'Sym':  0.0,     # score, asymptomatic
}

# State variable names in order
STATE_NAMES = ['A', 'Al', 'DC', 'Th2', 'Cyto', 'IgE', 'MC', 'Med', 'Eos', 'Sym']

# Variable labels for plotting
VAR_LABELS = {
    'A':    'Allergen (ng/mL)',
    'Al':   'Alarmins TSLP+IL-33 (pg/mL)',
    'DC':   'Activated DC (cells/μL)',
    'Th2':  'Activated Th2 (cells/μL)',
    'Cyto': 'Th2 Cytokines (pg/mL)',
    'IgE':  'Specific IgE (ng/mL)',
    'MC':   'Activated Mast Cells (fraction)',
    'Med':  'Mediators Hist+LT (ng/mL)',
    'Eos':  'Eosinophils (cells/μL)',
    'Sym':  'Symptom Score (0-10)',
}

# Variable colors for plotting (colorblind-friendly)
VAR_COLORS = {
    'A':    '#0279EE',
    'Al':   '#75A025',
    'DC':   '#FF9400',
    'Th2':  '#FD9BED',
    'Cyto': '#E9ED4C',
    'IgE':  '#0279EE',
    'MC':   '#FF9400',
    'Med':  '#75A025',
    'Eos':  '#FD9BED',
    'Sym':  '#000000',
}


def ode_system(t, y, params):
    """
    10-dimensional ODE system for SAR core pathway.

    Equations:
    (1)  dA/dt    = -k_A · A
    (2)  dAl/dt   = k_Al1 · A · (1 - Al/Al_max) - k_Al2 · Al
    (3)  dDC/dt   = k_DC1 · Al · (1 - DC/DC_max) - k_DC2 · DC
    (4)  dTh2/dt  = k_T1 · DC · (1 - Th2/Th2_max) - k_T2 · Th2
    (5)  dCyto/dt = k_C1 · Th2 - k_C2 · Cyto
    (6)  dIgE/dt  = k_IgE0 + k_IgE1 · Cyto - k_IgE2 · IgE
    (7)  dMC/dt   = k_MC1 · A · IgE · (1 - MC) - k_MC2 · MC
    (8)  dMed/dt  = k_Med1 · MC - k_Med2 · Med
    (9)  dEos/dt  = k_Eos1 · Cyto · (1 - Eos/Eos_max) - k_Eos2 · Eos
    (10) dSym/dt  = (k_S1 · Med + k_S2 · Eos) · (1 - Sym/Sym_max) - k_S3 · Sym

    Parameters
    ----------
    t : float
        Time in hours
    y : array-like, shape (10,)
        State vector [A, Al, DC, Th2, Cyto, IgE, MC, Med, Eos, Sym]
    params : dict
        Parameter dictionary

    Returns
    -------
    dydt : ndarray, shape (10,)
        Time derivatives
    """
    A, Al, DC, Th2, Cyto, IgE, MC, Med, Eos, Sym = y
    p = params

    # (1) Allergen clearance: first-order kinetics (mucociliary + immune)
    dA = -p['k_A'] * A

    # (2) Alarmin production (saturated) & degradation
    dAl = p['k_Al1'] * A * (1.0 - Al / p['Al_max']) - p['k_Al2'] * Al

    # (3) DC activation (saturated) & decay
    dDC = p['k_DC1'] * Al * (1.0 - DC / p['DC_max']) - p['k_DC2'] * DC

    # (4) Th2 activation (saturated) & decay
    dTh2 = p['k_T1'] * DC * (1.0 - Th2 / p['Th2_max']) - p['k_T2'] * Th2

    # (5) Cytokine production by Th2 & degradation
    dCyto = p['k_C1'] * Th2 - p['k_C2'] * Cyto

    # (6) IgE: baseline production + cytokine-driven - degradation
    dIgE = p['k_IgE0'] + p['k_IgE1'] * Cyto - p['k_IgE2'] * IgE

    # (7) Mast cell activation by A×IgE cross-linking (saturated 0-1) & recovery
    dMC = p['k_MC1'] * A * IgE * (1.0 - MC) - p['k_MC2'] * MC

    # (8) Mediator release by activated mast cells & fast clearance
    dMed = p['k_Med1'] * MC - p['k_Med2'] * Med

    # (9) Eosinophil recruitment (carrying capacity) & apoptosis
    dEos = p['k_Eos1'] * Cyto * (1.0 - Eos / p['Eos_max']) - p['k_Eos2'] * Eos

    # (10) Symptom: mediator-driven (immediate) + eosinophil-driven (late),
    #      saturated 0-10, with spontaneous resolution
    dSym = (p['k_S1'] * Med + p['k_S2'] * Eos) * (1.0 - Sym / p['Sym_max']) - p['k_S3'] * Sym

    return np.array([dA, dAl, dDC, dTh2, dCyto, dIgE, dMC, dMed, dEos, dSym])


def solve_model(params=None, ic=None, t_span=(0, 24), t_eval=None):
    """
    Solve the SAR ODE model.

    Parameters
    ----------
    params : dict or None
        Parameter dictionary (uses DEFAULT_PARAMS if None)
    ic : dict or None
        Initial conditions (uses DEFAULT_IC if None)
    t_span : tuple
        (t_start, t_end) in hours
    t_eval : array-like or None
        Time points for output (auto-generated if None)

    Returns
    -------
    result : Bunch object from solve_ivp with .t and .y
    """
    if params is None:
        params = DEFAULT_PARAMS.copy()
    if ic is None:
        ic = DEFAULT_IC.copy()
    if t_eval is None:
        t_eval = np.linspace(t_span[0], t_span[1], int((t_span[1] - t_span[0]) / 0.05) + 1)

    y0 = np.array([ic[name] for name in STATE_NAMES])

    result = solve_ivp(
        fun=lambda t, y: ode_system(t, y, params),
        t_span=t_span,
        y0=y0,
        t_eval=t_eval,
        method='LSODA',
        rtol=1e-8,
        atol=1e-10,
    )

    if not result.success:
        raise RuntimeError(f"ODE integration failed: {result.message}")

    return result


def result_to_dataframe(result):
    """Convert solve_ivp result to a labeled pandas DataFrame."""
    df = pd.DataFrame(result.y.T, columns=STATE_NAMES)
    df.insert(0, 'time_h', result.t)
    return df


def compute_metrics(result):
    """
    Compute key output metrics from a simulation result.

    Returns
    -------
    metrics : dict
        Sym_max, t_peak, AUC_0_24h for symptom score
    """
    sym = result.y[9]  # Symptom score
    t = result.t

    sym_max = np.max(sym)
    t_peak = t[np.argmax(sym)]
    auc = np.trapz(sym, t)

    return {
        'Sym_max': sym_max,
        't_peak_h': t_peak,
        'AUC_0_24h': auc,
    }


# ---------------------------------------------------------------------------
# Drug intervention parameter modifications
# ---------------------------------------------------------------------------
DRUG_INTERVENTIONS = {
    'Control': {},
    'Antihistamine (H1 blocker)': {
        'k_S1': DEFAULT_PARAMS['k_S1'] * 0.3,  # Block H1 receptor → reduce mediator→symptom
    },
    'Omalizumab (anti-IgE)': {
        # Override initial IgE and baseline production via custom IC
        '_ic_override': {'IgE': DEFAULT_IC['IgE'] * 0.3},
        'k_IgE0': DEFAULT_PARAMS['k_IgE0'] * 0.3,  # Neutralize IgE
    },
    'Dupilumab (anti-IL-4Rα)': {
        'k_C1': DEFAULT_PARAMS['k_C1'] * 0.2,    # Block IL-4/IL-13 signaling
        'k_IgE1': DEFAULT_PARAMS['k_IgE1'] * 0.2,  # Reduce cytokine-driven IgE
    },
    'Tezepelumab (anti-TSLP)': {
        'k_Al1': DEFAULT_PARAMS['k_Al1'] * 0.2,  # Block alarmin production
    },
}


def solve_with_intervention(intervention_name, t_span=(0, 24)):
    """
    Solve the model with a specified drug intervention.

    Parameters
    ----------
    intervention_name : str
        Key in DRUG_INTERVENTIONS

    Returns
    -------
    result : solve_ivp result
    """
    intervention = DRUG_INTERVENTIONS[intervention_name]
    params = DEFAULT_PARAMS.copy()
    ic = DEFAULT_IC.copy()

    for key, val in intervention.items():
        if key == '_ic_override':
            ic.update(val)
        else:
            params[key] = val

    return solve_model(params=params, ic=ic, t_span=t_span)


if __name__ == '__main__':
    # Quick test
    res = solve_model()
    df = result_to_dataframe(res)
    metrics = compute_metrics(res)
    print("Model solved successfully.")
    print(f"Time points: {len(res.t)}")
    print(f"Sym_max: {metrics['Sym_max']:.2f}")
    print(f"t_peak: {metrics['t_peak_h']:.2f} h")
    print(f"AUC_0_24h: {metrics['AUC_0_24h']:.2f}")
