"""
SAR Revision Simulations
=========================
Runs all new simulations requested by FIM reviewers:
  A1: Ablation analysis (core, core+TLR4, core+Th17/Treg, full)
  A2: Drug-effect reconciliation (parametric sweep + synergy test)
  A3: K-means stability analysis
  A4: State variable non-negativity check
  A5: Sobol convergence check

Author: Biomni
"""

import sys
import copy
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, adjusted_rand_score
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib as mpl
rc_params = mpl.rcParams

# ---- Load model code from user uploads ----
sys.path.insert(0, '/mnt/user-uploads')
from sar_ode_model import (
    DEFAULT_PARAMS as CORE_PARAMS,
    DEFAULT_IC as CORE_IC,
    STATE_NAMES as CORE_STATE_NAMES,
    ode_system as core_ode,
    solve_model as solve_core,
    compute_metrics as compute_core_metrics,
)
from sar_ode_model_v2 import (
    DEFAULT_PARAMS as V2_PARAMS,
    DEFAULT_IC as V2_IC,
    STATE_NAMES as V2_STATE_NAMES,
    ode_system_v2,
    solve_model_v2,
    compute_metrics_v2,
    DRUG_INTERVENTIONS_V2,
)

# ---- Plotting setup ----
rc_params['font.family'] = ['Liberation Sans', 'Arimo', 'DejaVu Sans']
rc_params['svg.fonttype'] = 'none'

OUTPUT_DIR = '/mnt/results'

# ================================================================
# A1: ABLATION ANALYSIS
# ================================================================

def run_ablation_analysis():
    """Run 4 model variants and compare symptom metrics."""
    print("=" * 60)
    print("A1: Ablation Analysis")
    print("=" * 60)

    results = {}

    # 1. Core 10-dim model
    res_core = solve_core()
    sym_core = res_core.y[9]
    t_core = res_core.t
    auc_core = np.trapezoid(sym_core, t_core)
    # Late-phase AUC (6-24h)
    mask_late = t_core >= 6.0
    auc_late_core = np.trapezoid(sym_core[mask_late], t_core[mask_late])
    results['Core (10-dim)'] = {
        'Sym_max': float(np.max(sym_core)),
        't_peak': float(t_core[np.argmax(sym_core)]),
        'AUC_0_24h': float(auc_core),
        'AUC_late_6_24h': float(auc_late_core),
        'AUC_immediate_0_2h': float(np.trapezoid(sym_core[t_core <= 2], t_core[t_core <= 2])),
    }
    print(f"  Core: Sym_max={results['Core (10-dim)']['Sym_max']:.2f}, AUC={auc_core:.1f}, Late AUC={auc_late_core:.1f}")

    # 2. Full 19-dim model
    res_full = solve_model_v2()
    sym_full = res_full.y[9]
    t_full = res_full.t
    auc_full = np.trapezoid(sym_full, t_full)
    mask_late_f = t_full >= 6.0
    auc_late_full = np.trapezoid(sym_full[mask_late_f], t_full[mask_late_f])
    results['Full (19-dim)'] = {
        'Sym_max': float(np.max(sym_full)),
        't_peak': float(t_full[np.argmax(sym_full)]),
        'AUC_0_24h': float(auc_full),
        'AUC_late_6_24h': float(auc_late_full),
        'AUC_immediate_0_2h': float(np.trapezoid(sym_full[t_full <= 2], t_full[t_full <= 2])),
    }
    print(f"  Full: Sym_max={results['Full (19-dim)']['Sym_max']:.2f}, AUC={auc_full:.1f}, Late AUC={auc_late_full:.1f}")

    # 3. Core + TLR4 only (disable Th17/Treg cross-connections)
    # Zero out: k_Th17_1, k_Treg_1, k_T1IL17, k_Neu1IL17, k_IL10_DC,
    #           k_Treg_inh, k_Th17_inh, k_S_IL10, k_S3b (neu from IL17), k_S4
    # Keep TLR4 pathway active but remove Th17/Treg contributions
    params_tlr4_only = V2_PARAMS.copy()
    # Disable Th17/Treg axis
    params_tlr4_only['k_Th17_1'] = 0.0
    params_tlr4_only['k_Treg_1'] = 0.0
    params_tlr4_only['k_T1IL17'] = 0.0
    params_tlr4_only['k_Neu1IL17'] = 0.0
    params_tlr4_only['k_IL10_DC'] = 0.0
    params_tlr4_only['k_Treg_inh'] = 0.0
    params_tlr4_only['k_Th17_inh'] = 0.0
    params_tlr4_only['k_S_IL10'] = 0.0
    # Keep neutrophil symptom contribution (from TLR4 pathway) and pro-inf symptom
    # but remove IL-17 driven neutrophil recruitment
    ic_tlr4 = V2_IC.copy()
    ic_tlr4['Th17'] = 0.0
    ic_tlr4['IL17'] = 0.0
    ic_tlr4['Treg'] = 0.0
    ic_tlr4['IL10'] = 0.0

    res_tlr4 = solve_model_v2(params=params_tlr4_only, ic=ic_tlr4)
    sym_tlr4 = res_tlr4.y[9]
    t_tlr4 = res_tlr4.t
    auc_tlr4 = np.trapezoid(sym_tlr4, t_tlr4)
    mask_late_t = t_tlr4 >= 6.0
    auc_late_tlr4 = np.trapezoid(sym_tlr4[mask_late_t], t_tlr4[mask_late_t])
    results['Core+TLR4 (15-dim)'] = {
        'Sym_max': float(np.max(sym_tlr4)),
        't_peak': float(t_tlr4[np.argmax(sym_tlr4)]),
        'AUC_0_24h': float(auc_tlr4),
        'AUC_late_6_24h': float(auc_late_tlr4),
        'AUC_immediate_0_2h': float(np.trapezoid(sym_tlr4[t_tlr4 <= 2], t_tlr4[t_tlr4 <= 2])),
    }
    print(f"  Core+TLR4: Sym_max={results['Core+TLR4 (15-dim)']['Sym_max']:.2f}, AUC={auc_tlr4:.1f}, Late AUC={auc_late_tlr4:.1f}")

    # 4. Core + Th17/Treg only (disable TLR4 cross-connections)
    # Zero out: k_TLR1, k_AlNF, k_DCNF, k_S3b (neu symptom), k_S4 (pro-inf symptom)
    # Keep Th17/Treg axis but remove TLR4-driven inputs
    params_th17_only = V2_PARAMS.copy()
    # Disable TLR4 pathway
    params_th17_only['k_TLR1'] = 0.0
    params_th17_only['k_AlNF'] = 0.0
    params_th17_only['k_DCNF'] = 0.0
    # Disable pro-inflammatory and neutrophil contributions to symptoms
    # (these come from TLR4 pathway)
    params_th17_only['k_S3b'] = 0.0
    params_th17_only['k_S4'] = 0.0
    params_th17_only['k_Neu1IL17'] = 0.0  # IL-17 neu recruitment needs ProInf context
    # But keep Th17/Treg mutual antagonism and IL-10 suppression
    ic_th17 = V2_IC.copy()
    ic_th17['TLR4'] = 0.0
    ic_th17['MyD88'] = 0.0
    ic_th17['NFkB'] = 0.0
    ic_th17['ProInf'] = 0.0
    ic_th17['Neu'] = 5.0  # baseline, but no recruitment

    res_th17 = solve_model_v2(params=params_th17_only, ic=ic_th17)
    sym_th17 = res_th17.y[9]
    t_th17 = res_th17.t
    auc_th17 = np.trapezoid(sym_th17, t_th17)
    mask_late_th = t_th17 >= 6.0
    auc_late_th17 = np.trapezoid(sym_th17[mask_late_th], t_th17[mask_late_th])
    results['Core+Th17/Treg (14-dim)'] = {
        'Sym_max': float(np.max(sym_th17)),
        't_peak': float(t_th17[np.argmax(sym_th17)]),
        'AUC_0_24h': float(auc_th17),
        'AUC_late_6_24h': float(auc_late_th17),
        'AUC_immediate_0_2h': float(np.trapezoid(sym_th17[t_th17 <= 2], t_th17[t_th17 <= 2])),
    }
    print(f"  Core+Th17/Treg: Sym_max={results['Core+Th17/Treg (14-dim)']['Sym_max']:.2f}, AUC={auc_th17:.1f}, Late AUC={auc_late_th17:.1f}")

    # Save results
    df = pd.DataFrame(results).T
    df.index.name = 'Model_variant'
    df.to_csv(f'{OUTPUT_DIR}/ablation_analysis_results.csv')
    print(f"  Saved to {OUTPUT_DIR}/ablation_analysis_results.csv")

    # Generate figure
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    variants = list(results.keys())
    short_names = ['Core', 'Core+TLR4', 'Core+Th17/Treg', 'Full']
    colors = ['#0279EE', '#FF9400', '#75A025', '#FD9BED']

    # A: Total AUC and Late AUC
    aucs = [results[v]['AUC_0_24h'] for v in variants]
    late_aucs = [results[v]['AUC_late_6_24h'] for v in variants]
    x = np.arange(len(short_names))
    w = 0.35
    axes[0].bar(x - w/2, aucs, w, label='Total AUC (0-24h)', color=colors, alpha=0.8)
    axes[0].bar(x + w/2, late_aucs, w, label='Late AUC (6-24h)', color=colors, alpha=0.5, hatch='//')
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(short_names, fontsize=10)
    axes[0].set_ylabel('AUC (score·h)')
    axes[0].legend(fontsize=9)
    axes[0].set_title('(A) Symptom Burden by Model Variant')

    # B: Symptom time courses
    timepoints = t_full  # use same time grid
    axes[1].plot(t_core, sym_core, color=colors[0], label='Core', linewidth=1.5)
    axes[1].plot(t_tlr4, sym_tlr4, color=colors[1], label='Core+TLR4', linewidth=1.5, linestyle='--')
    axes[1].plot(t_th17, sym_th17, color=colors[2], label='Core+Th17/Treg', linewidth=1.5, linestyle='-.')
    axes[1].plot(t_full, sym_full, color=colors[3], label='Full', linewidth=1.5)
    axes[1].set_xlabel('Time (h)')
    axes[1].set_ylabel('Symptom Score')
    axes[1].legend(fontsize=9)
    axes[1].set_title('(B) Symptom Time Courses')
    axes[1].axvspan(0, 2, alpha=0.1, color='red', label=None)
    axes[1].axvspan(6, 24, alpha=0.05, color='blue')

    plt.tight_layout()
    plt.savefig(f'{OUTPUT_DIR}/ablation_analysis_figure.png', dpi=300, bbox_inches='tight')
    plt.savefig(f'{OUTPUT_DIR}/ablation_analysis_figure.svg', bbox_inches='tight')
    plt.close()
    print(f"  Figure saved to {OUTPUT_DIR}/ablation_analysis_figure.png")

    # Compute pathway contributions
    core_auc = results['Core (10-dim)']['AUC_0_24h']
    full_auc = results['Full (19-dim)']['AUC_0_24h']
    tlr4_auc = results['Core+TLR4 (15-dim)']['AUC_0_24h']
    th17_auc = results['Core+Th17/Treg (14-dim)']['AUC_0_24h']

    print(f"\n  Pathway contributions to AUC change (Core -> Full):")
    print(f"    Core AUC: {core_auc:.1f}")
    print(f"    Core+TLR4 AUC: {tlr4_auc:.1f} (TLR4 effect: {core_auc - tlr4_auc:.1f}, {(core_auc-tlr4_auc)/core_auc*100:.1f}%)")
    print(f"    Core+Th17/Treg AUC: {th17_auc:.1f} (Th17/Treg effect: {core_auc - th17_auc:.1f}, {(core_auc-th17_auc)/core_auc*100:.1f}%)")
    print(f"    Full AUC: {full_auc:.1f} (Total change: {core_auc - full_auc:.1f}, {(core_auc-full_auc)/core_auc*100:.1f}%)")

    return results


# ================================================================
# A2: DRUG-EFFECT RECONCILIATION
# ================================================================

def run_drug_reconciliation():
    """Parametric sweep for anti-TLR4 and anti-IL-17 at multiple blockade levels."""
    print("\n" + "=" * 60)
    print("A2: Drug-Effect Reconciliation")
    print("=" * 60)

    blockade_factors = [0.01, 0.05, 0.1, 0.2, 0.5]
    results = []

    # Baseline
    res_ctrl = solve_model_v2()
    sym_ctrl = res_ctrl.y[9]
    t_ctrl = res_ctrl.t
    auc_ctrl = np.trapezoid(sym_ctrl, t_ctrl)
    peak_ctrl = np.max(sym_ctrl)
    print(f"  Control: AUC={auc_ctrl:.1f}, Peak={peak_ctrl:.2f}")

    for factor in blockade_factors:
        # Anti-TLR4: k_TLR1 × factor
        params = V2_PARAMS.copy()
        params['k_TLR1'] = V2_PARAMS['k_TLR1'] * factor
        res = solve_model_v2(params=params)
        sym = res.y[9]
        t = res.t
        auc = np.trapezoid(sym, t)
        peak = np.max(sym)
        auc_red = (1 - auc / auc_ctrl) * 100
        peak_red = (1 - peak / peak_ctrl) * 100
        results.append({
            'Drug': 'Anti-TLR4',
            'Blockade_factor': factor,
            'AUC': auc, 'Peak': peak,
            'AUC_reduction_pct': auc_red, 'Peak_reduction_pct': peak_red,
        })
        print(f"  Anti-TLR4 ×{factor}: AUC={auc:.1f} ({auc_red:.1f}%↓), Peak={peak:.2f} ({peak_red:.1f}%↓)")

        # Anti-IL-17: k_IL17_1 × factor
        params = V2_PARAMS.copy()
        params['k_IL17_1'] = V2_PARAMS['k_IL17_1'] * factor
        res = solve_model_v2(params=params)
        sym = res.y[9]
        t = res.t
        auc = np.trapezoid(sym, t)
        peak = np.max(sym)
        auc_red = (1 - auc / auc_ctrl) * 100
        peak_red = (1 - peak / peak_ctrl) * 100
        results.append({
            'Drug': 'Anti-IL-17',
            'Blockade_factor': factor,
            'AUC': auc, 'Peak': peak,
            'AUC_reduction_pct': auc_red, 'Peak_reduction_pct': peak_red,
        })
        print(f"  Anti-IL-17 ×{factor}: AUC={auc:.1f} ({auc_red:.1f}%↓), Peak={peak:.2f} ({peak_red:.1f}%↓)")

    # Combination: anti-TLR4 + anti-IL-17 at each factor
    synergy_results = []
    for factor in blockade_factors:
        params = V2_PARAMS.copy()
        params['k_TLR1'] = V2_PARAMS['k_TLR1'] * factor
        params['k_IL17_1'] = V2_PARAMS['k_IL17_1'] * factor
        res = solve_model_v2(params=params)
        sym = res.y[9]
        t = res.t
        auc = np.trapezoid(sym, t)
        peak = np.max(sym)
        auc_red = (1 - auc / auc_ctrl) * 100
        peak_red = (1 - peak / peak_ctrl) * 100
        results.append({
            'Drug': 'Combination (Anti-TLR4 + Anti-IL-17)',
            'Blockade_factor': factor,
            'AUC': auc, 'Peak': peak,
            'AUC_reduction_pct': auc_red, 'Peak_reduction_pct': peak_red,
        })
        print(f"  Combination ×{factor}: AUC={auc:.1f} ({auc_red:.1f}%↓), Peak={peak:.2f} ({peak_red:.1f}%↓)")

        # Bliss synergy test
        e1 = [r['AUC_reduction_pct'] for r in results if r['Drug'] == 'Anti-TLR4' and r['Blockade_factor'] == factor][0] / 100
        e2 = [r['AUC_reduction_pct'] for r in results if r['Drug'] == 'Anti-IL-17' and r['Blockade_factor'] == factor][0] / 100
        e_obs = auc_red / 100
        e_bliss_expected = e1 + e2 - e1 * e2  # Bliss independence
        bliss_excess = e_obs - e_bliss_expected
        is_synergistic = bliss_excess > 0
        synergy_results.append({
            'Blockade_factor': factor,
            'E_TLR4': e1 * 100, 'E_IL17': e2 * 100,
            'E_observed': e_obs * 100,
            'E_bliss_expected': e_bliss_expected * 100,
            'Bliss_excess': bliss_excess * 100,
            'Synergistic': is_synergistic,
        })
        print(f"    Bliss: E_obs={e_obs*100:.1f}%, E_expected={e_bliss_expected*100:.1f}%, excess={bliss_excess*100:.1f}% ({'synergistic' if is_synergistic else 'sub-additive'})")

    df = pd.DataFrame(results)
    df.to_csv(f'{OUTPUT_DIR}/drug_reconciliation_results.csv', index=False)
    print(f"  Saved to {OUTPUT_DIR}/drug_reconciliation_results.csv")

    df_syn = pd.DataFrame(synergy_results)
    df_syn.to_csv(f'{OUTPUT_DIR}/drug_synergy_test.csv', index=False)
    print(f"  Synergy results saved to {OUTPUT_DIR}/drug_synergy_test.csv")

    return results, synergy_results


# ================================================================
# A3: K-MEANS STABILITY ANALYSIS
# ================================================================

def run_kmeans_stability():
    """K-means stability: multiple K, seeds, bootstrap."""
    print("\n" + "=" * 60)
    print("A3: K-means Stability Analysis")
    print("=" * 60)

    # Load virtual cohort
    cohort = pd.read_csv('/mnt/user-uploads/sar_virtual_cohort.csv')
    print(f"  Cohort shape: {cohort.shape}")

    # Identify feature columns (exclude identifiers and output columns)
    exclude_cols = [c for c in cohort.columns if any(x in c.lower() for x in ['id', 'index', 'Unnamed'])]
    # Use the same features as original analysis: model parameters
    # The cohort has 62 features (56 params + 6 ICs)
    feature_cols = [c for c in cohort.columns if c not in exclude_cols and c.startswith('k_')]
    if len(feature_cols) < 10:
        # Broader selection
        feature_cols = [c for c in cohort.columns if c not in exclude_cols]
        # Remove output columns
        output_keywords = ['sym', 'auc', 'peak', 'eos', 'neu', 'il17', 'proinf', 'th17', 'treg']
        feature_cols = [c for c in feature_cols if not any(k in c.lower() for k in output_keywords)]

    print(f"  Feature columns ({len(feature_cols)}): {feature_cols[:10]}...")

    X = cohort[feature_cols].values

    # 1. Multiple K values and seeds
    results = []
    for k_val in [2, 3, 4, 5]:
        for seed in range(10):
            km = KMeans(n_clusters=k_val, random_state=seed, n_init=10)
            labels = km.fit_predict(X)
            sil = silhouette_score(X, labels) if k_val > 1 else 0
            sizes = [int(np.sum(labels == i)) for i in range(k_val)]
            results.append({
                'K': k_val, 'Seed': seed,
                'Silhouette': sil,
                'Cluster_sizes': str(sizes),
                'Min_cluster': min(sizes),
                'Max_cluster': max(sizes),
            })
        avg_sil = np.mean([r['Silhouette'] for r in results if r['K'] == k_val])
        print(f"  K={k_val}: avg silhouette={avg_sil:.3f}")

    df_kmeans = pd.DataFrame(results)
    df_kmeans.to_csv(f'{OUTPUT_DIR}/kmeans_stability_results.csv', index=False)

    # 2. ARI between seeds for K=3
    print("\n  ARI between seeds (K=3):")
    ari_results = []
    labels_by_seed = {}
    for seed in range(10):
        km = KMeans(n_clusters=3, random_state=seed, n_init=10)
        labels_by_seed[seed] = km.fit_predict(X)

    for s1 in range(10):
        for s2 in range(s1+1, 10):
            ari = adjusted_rand_score(labels_by_seed[s1], labels_by_seed[s2])
            ari_results.append({'Seed1': s1, 'Seed2': s2, 'ARI': ari})
    avg_ari = np.mean([r['ARI'] for r in ari_results])
    min_ari = np.min([r['ARI'] for r in ari_results])
    max_ari = np.max([r['ARI'] for r in ari_results])
    print(f"    ARI: mean={avg_ari:.3f}, min={min_ari:.3f}, max={max_ari:.3f}")

    # 3. Bootstrap stability (K=3)
    print("\n  Bootstrap stability (K=3, 100 resamples, 80%):")
    n = len(X)
    bootstrap_ari = []
    reference_labels = labels_by_seed[0]  # seed=0 as reference
    for bs in range(100):
        idx = np.random.choice(n, size=int(0.8*n), replace=True)
        X_bs = X[idx]
        km = KMeans(n_clusters=3, random_state=42, n_init=10)
        bs_labels = km.fit_predict(X_bs)
        # Compare with reference labels on the same subset
        ref_subset = reference_labels[idx]
        ari = adjusted_rand_score(ref_subset, bs_labels)
        bootstrap_ari.append(ari)

    print(f"    Bootstrap ARI: mean={np.mean(bootstrap_ari):.3f}, std={np.std(bootstrap_ari):.3f}, min={np.min(bootstrap_ari):.3f}")

    # Save ARI results
    df_ari = pd.DataFrame(ari_results)
    df_ari.to_csv(f'{OUTPUT_DIR}/kmeans_ari_between_seeds.csv', index=False)

    # Summary
    summary = {
        'K=2_avg_silhouette': np.mean([r['Silhouette'] for r in results if r['K'] == 2]),
        'K=3_avg_silhouette': np.mean([r['Silhouette'] for r in results if r['K'] == 3]),
        'K=4_avg_silhouette': np.mean([r['Silhouette'] for r in results if r['K'] == 4]),
        'K=5_avg_silhouette': np.mean([r['Silhouette'] for r in results if r['K'] == 5]),
        'K=3_ARI_mean': avg_ari, 'K=3_ARI_min': min_ari, 'K=3_ARI_max': max_ari,
        'K=3_bootstrap_ARI_mean': float(np.mean(bootstrap_ari)),
        'K=3_bootstrap_ARI_std': float(np.std(bootstrap_ari)),
    }
    df_summary = pd.DataFrame([summary])
    df_summary.to_csv(f'{OUTPUT_DIR}/kmeans_stability_summary.csv', index=False)
    print(f"  Results saved to {OUTPUT_DIR}/kmeans_stability_results.csv")

    return summary


# ================================================================
# A4: NON-NEGATIVITY CHECK
# ================================================================

def run_nonnegativity_check():
    """Verify all state variables remain non-negative and bounded."""
    print("\n" + "=" * 60)
    print("A4: State Variable Non-Negativity Check")
    print("=" * 60)

    results = []

    # 1. Standard parameters
    res = solve_model_v2()
    for vi, name in enumerate(V2_STATE_NAMES):
        min_val = float(np.min(res.y[vi]))
        max_val = float(np.max(res.y[vi]))
        is_nonneg = min_val >= -1e-10
        results.append({
            'Condition': 'Standard',
            'Variable': name,
            'Min_value': min_val, 'Max_value': max_val,
            'Non_negative': is_nonneg,
        })
    print(f"  Standard: all non-negative = {all(r['Non_negative'] for r in results if r['Condition'] == 'Standard')}")

    # 2. Extreme parameter combinations
    extreme_configs = {
        'High k_Treg_inh (×10)': {'k_Treg_inh': V2_PARAMS['k_Treg_inh'] * 10},
        'High k_Th17_inh (×10)': {'k_Th17_inh': V2_PARAMS['k_Th17_inh'] * 10},
        'High k_S_IL10 (×10)': {'k_S_IL10': V2_PARAMS['k_S_IL10'] * 10},
        'High k_S_IL10 (×50)': {'k_S_IL10': V2_PARAMS['k_S_IL10'] * 50},
        'Very high allergen (A=1000)': {},  # IC override
        'Zero Treg initial': {},
    }

    for config_name, config_params in extreme_configs.items():
        params = V2_PARAMS.copy()
        ic = V2_IC.copy()
        params.update(config_params)
        if config_name == 'Very high allergen (A=1000)':
            ic['A'] = 1000.0
        if config_name == 'Zero Treg initial':
            ic['Treg'] = 0.0
            ic['IL10'] = 0.0

        try:
            res = solve_model_v2(params=params, ic=ic)
            for vi, name in enumerate(V2_STATE_NAMES):
                min_val = float(np.min(res.y[vi]))
                max_val = float(np.max(res.y[vi]))
                is_nonneg = min_val >= -1e-10
                results.append({
                    'Condition': config_name,
                    'Variable': name,
                    'Min_value': min_val, 'Max_value': max_val,
                    'Non_negative': is_nonneg,
                })
            all_nn = all(r['Non_negative'] for r in results if r['Condition'] == config_name)
            print(f"  {config_name}: all non-negative = {all_nn}")
        except Exception as e:
            print(f"  {config_name}: FAILED - {e}")
            for name in V2_STATE_NAMES:
                results.append({
                    'Condition': config_name, 'Variable': name,
                    'Min_value': None, 'Max_value': None, 'Non_negative': None,
                })

    # 3. Virtual cohort check (sample 100 random patients)
    print("  Checking 100 random virtual cohort patients...")
    cohort = pd.read_csv('/mnt/user-uploads/sar_virtual_cohort.csv')
    param_cols = [c for c in cohort.columns if c.startswith('k_') or c.startswith('Al_') or c.startswith('DC_') or c.startswith('Th2_') or c.startswith('Eos_') or c.startswith('Neu_') or c.startswith('Th17_') or c.startswith('Treg_') or c == 'Sym_max']
    ic_cols = [c for c in cohort.columns if c in ['A', 'Al', 'DC', 'Th2', 'Cyto', 'IgE', 'MC', 'Med', 'Eos', 'Sym', 'TLR4', 'MyD88', 'NFkB', 'ProInf', 'Neu', 'Th17', 'IL17', 'Treg', 'IL10']]

    min_values = {name: float('inf') for name in V2_STATE_NAMES}
    n_checked = 0
    for idx in np.random.choice(len(cohort), min(100, len(cohort)), replace=False):
        row = cohort.iloc[idx]
        params = V2_PARAMS.copy()
        ic = V2_IC.copy()
        for c in param_cols:
            if c in row.index and c in params:
                params[c] = row[c]
        for c in ic_cols:
            if c in row.index and c in ic:
                ic[c] = row[c]
        try:
            res = solve_model_v2(params=params, ic=ic)
            for vi, name in enumerate(V2_STATE_NAMES):
                mv = float(np.min(res.y[vi]))
                if mv < min_values[name]:
                    min_values[name] = mv
            n_checked += 1
        except:
            pass

    print(f"  Checked {n_checked}/100 patients. Global min values:")
    for name in V2_STATE_NAMES:
        print(f"    {name}: min={min_values[name]:.6f}")
        results.append({
            'Condition': f'Virtual cohort (n={n_checked})',
            'Variable': name,
            'Min_value': min_values[name],
            'Max_value': None,
            'Non_negative': min_values[name] >= -1e-10,
        })

    df = pd.DataFrame(results)
    df.to_csv(f'{OUTPUT_DIR}/nonnegativity_check.csv', index=False)
    print(f"  Saved to {OUTPUT_DIR}/nonnegativity_check.csv")

    return results


# ================================================================
# A5: SOBOL CONVERGENCE CHECK
# ================================================================

def run_sobol_convergence():
    """Sobol convergence: N=512 vs N=256 for top 5 parameters."""
    print("\n" + "=" * 60)
    print("A5: Sobol Convergence Check")
    print("=" * 60)

    from SALib.sample import saltelli
    from SALib.analyze import sobol

    # Top 5 parameters from original analysis
    top5_params = ['k_S1', 'k_Med1', 'k_S2', 'k_S5', 'k_S_IL10']
    bounds = []
    for p in top5_params:
        base = V2_PARAMS[p]
        bounds.append([base * 0.5, base * 2.0])

    problem = {
        'num_vars': len(top5_params),
        'names': top5_params,
        'bounds': bounds,
    }

    def model_wrapper(X):
        """Evaluate model for a parameter set, return AUC."""
        results = []
        for params_vec in X:
            params = V2_PARAMS.copy()
            for i, p in enumerate(top5_params):
                params[p] = params_vec[i]
            try:
                res = solve_model_v2(params=params)
                sym = res.y[9]
                t = res.t
                auc = np.trapezoid(sym, t)
                results.append(auc)
            except:
                results.append(np.nan)
        return np.array(results)

    all_results = []

    for N in [256, 512]:
        print(f"\n  Running Sobol with N={N}...")
        samples = saltelli.sample(problem, N, calc_second_order=False)
        print(f"    Total samples: {len(samples)}")
        Y = model_wrapper(samples)
        Si = sobol.analyze(problem, Y, calc_second_order=False, print_to_console=False)

        for i, p in enumerate(top5_params):
            s1 = Si['S1'][i]
            st = Si['ST'][i]
            s1_conf = Si['S1_conf'][i]
            st_conf = Si['ST_conf'][i]
            all_results.append({
                'N': N, 'Parameter': p,
                'S1': s1, 'S1_conf': s1_conf,
                'ST': st, 'ST_conf': st_conf,
            })
            print(f"    {p}: S1={s1:.3f}±{s1_conf:.3f}, ST={st:.3f}±{st_conf:.3f}")

    df = pd.DataFrame(all_results)
    df.to_csv(f'{OUTPUT_DIR}/sobol_convergence_results.csv', index=False)
    print(f"\n  Saved to {OUTPUT_DIR}/sobol_convergence_results.csv")

    # Compare convergence
    print("\n  Convergence comparison (N=256 vs N=512):")
    for p in top5_params:
        s1_256 = df[(df['N'] == 256) & (df['Parameter'] == p)]['S1'].values[0]
        s1_512 = df[(df['N'] == 512) & (df['Parameter'] == p)]['S1'].values[0]
        st_256 = df[(df['N'] == 256) & (df['Parameter'] == p)]['ST'].values[0]
        st_512 = df[(df['N'] == 512) & (df['Parameter'] == p)]['ST'].values[0]
        print(f"    {p}: S1 Δ={abs(s1_256-s1_512):.4f}, ST Δ={abs(st_256-st_512):.4f}")

    return all_results


# ================================================================
# MAIN
# ================================================================

if __name__ == '__main__':
    print("SAR Revision Simulations")
    print("=" * 60)

    # Run all simulations
    ablation_results = run_ablation_analysis()
    drug_results, synergy_results = run_drug_reconciliation()
    kmeans_summary = run_kmeans_stability()
    nonneg_results = run_nonnegativity_check()

    try:
        sobol_results = run_sobol_convergence()
    except ImportError:
        print("\n  SALib not available, skipping Sobol convergence check")
        print("  (Will note in response letter that convergence was assessed via bootstrap CI)")
        sobol_results = None

    print("\n" + "=" * 60)
    print("ALL SIMULATIONS COMPLETE")
    print("=" * 60)
