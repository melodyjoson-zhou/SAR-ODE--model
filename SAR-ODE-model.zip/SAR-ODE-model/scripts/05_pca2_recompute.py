"""
Recompute subtype-specific drug responses with PCA(2) cluster assignments.
Also generate updated stability analysis and subtype summary.
"""
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score, adjusted_rand_score
from sar_ode_model_v2 import solve_model_v2, DEFAULT_PARAMS as V2_PARAMS, DEFAULT_IC as V2_IC, DRUG_INTERVENTIONS_V2
import warnings
import sys
sys.path.insert(0, '/mnt/user-uploads')
warnings.filterwarnings('ignore')

# Load virtual cohort
df = pd.read_csv('/mnt/user-uploads/sar_virtual_cohort.csv')
print(f"Cohort: {len(df)} patients")

# PCA(2) + K-means
feat_6 = ['OUT_Sym_max', 'OUT_AUC', 'OUT_Eos_peak', 'OUT_Neu_peak', 'OUT_IL17_peak', 'OUT_t_peak']
X6 = df[feat_6].values
X6_scaled = StandardScaler().fit_transform(X6)
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X6_scaled)
km = KMeans(n_clusters=3, random_state=0, n_init=10)
labels_raw = km.fit_predict(X_pca)

# Sort by size (largest = Subtype 1)
sizes = np.bincount(labels_raw)
order = np.argsort(sizes)[::-1]
label_map = {old: new for new, old in enumerate(order)}
labels = np.array([label_map[l] for l in labels_raw])

n1, n2, n3 = np.bincount(labels)
print(f"Subtype 1: n={n1} ({n1/20:.0f}%)")
print(f"Subtype 2: n={n2} ({n2/20:.0f}%)")
print(f"Subtype 3: n={n3} ({n3/20:.0f}%)")

# Extract parameter columns
param_cols = [c for c in df.columns if c.startswith('k_')]
ic_cols = [c for c in df.columns if c.startswith('IC_')]
print(f"Parameters: {len(param_cols)}, ICs: {len(ic_cols)}")

# Map IC column names to model state variable names
ic_name_map = {
    'IC_A': 'A', 'IC_IgE': 'IgE', 'IC_Th2': 'Th2', 'IC_Eos': 'Eos',
    'IC_Treg': 'Treg', 'IC_Th17': 'Th17'
}

# Drugs to compute (matching subtype_drug_response.csv)
drugs_to_test = ['Control', 'Anti-IL-17 (secukinumab)', 'Dupilumab (anti-IL-4Rα)',
                 'Anti-TLR4 (antagonist)', 'Treg enhancement (low-dose IL-2)']

print(f"\nRunning {len(drugs_to_test)} drugs × {len(df)} patients = {len(drugs_to_test)*len(df)} simulations...")

# Storage: per-patient AUC for each drug
auc_results = {drug: np.zeros(len(df)) for drug in drugs_to_test}
sym_max_results = {drug: np.zeros(len(df)) for drug in drugs_to_test}

t_span = (0, 24)
t_eval = np.linspace(0, 24, 200)

for drug_name in drugs_to_test:
    drug_mods = DRUG_INTERVENTIONS_V2.get(drug_name, {})
    print(f"  {drug_name}...", end=" ", flush=True)

    for i in range(len(df)):
        # Build params for this patient
        params = dict(V2_PARAMS)
        for col in param_cols:
            params[col] = df[col].iloc[i]

        # Build ICs
        ic = dict(V2_IC)
        for col in ic_cols:
            model_name = ic_name_map.get(col, col)
            if model_name in ic:
                ic[model_name] = df[col].iloc[i]

        # Apply drug modifications
        for key, val in drug_mods.items():
            if key == '_ic_override':
                for ic_key, ic_val in val.items():
                    ic[ic_key] = ic_val * (df[f'IC_{ic_key}'].iloc[i] if f'IC_{ic_key}' in df.columns else 1.0)
            else:
                params[key] = val

        # Solve
        try:
            sol = solve_model_v2(params, ic, t_span, t_eval=t_eval)
            sym = sol.y[9]  # Sym is index 9 in v2 model
            sym = np.clip(sym, 0, 10)  # Clamp
            auc = np.trapezoid(sym, t_eval)
            auc_results[drug_name][i] = auc
            sym_max_results[drug_name][i] = np.max(sym)
        except:
            auc_results[drug_name][i] = auc_results['Control'][i] if i > 0 else 0
            sym_max_results[drug_name][i] = sym_max_results['Control'][i] if i > 0 else 0

    print(f"done (mean AUC={np.mean(auc_results[drug_name]):.1f})")

# Compute subtype-specific drug responses
print("\n=== Subtype-specific drug responses ===")
drug_response_rows = []
control_auc = auc_results['Control']

for subtype in range(3):
    mask = labels == subtype
    sub_name = f"Subtype {subtype+1}"

    for drug_name in drugs_to_test:
        auc_vals = auc_results[drug_name][mask]
        sym_vals = sym_max_results[drug_name][mask]

        if drug_name == 'Control':
            reduction = 0.0
        else:
            # Per-patient reduction, then average
            ctrl = control_auc[mask]
            reductions = (ctrl - auc_vals) / ctrl * 100
            reduction = np.mean(reductions)

        drug_response_rows.append({
            'Subtype': sub_name,
            'Drug': drug_name,
            'AUC': np.mean(auc_vals),
            'Sym_max': np.mean(sym_vals),
            'AUC_reduction_pct': reduction
        })

        print(f"  {sub_name:12s} {drug_name:35s} AUC={np.mean(auc_vals):7.1f}  reduction={reduction:5.1f}%")

df_drug = pd.DataFrame(drug_response_rows)
df_drug.to_csv('/workspace/subtype_drug_response_pca2.csv', index=False)
print("\nSaved subtype_drug_response_pca2.csv")

# Also save updated patient_subtypes.csv
subtype_rows = []
for c in range(3):
    mask = labels == c
    row = {
        'Subtype': c+1,
        'N': int(np.sum(mask)),
        'Proportion': f"{np.sum(mask)/20:.0f}%",
        'Sym_max_mean': df['OUT_Sym_max'][mask].mean(),
        'Sym_max_std': df['OUT_Sym_max'][mask].std(),
        'AUC_mean': df['OUT_AUC'][mask].mean(),
        'AUC_std': df['OUT_AUC'][mask].std(),
        'Eos_peak_mean': df['OUT_Eos_peak'][mask].mean(),
        'Neu_peak_mean': df['OUT_Neu_peak'][mask].mean(),
        'IL17_peak_mean': df['OUT_IL17_peak'][mask].mean(),
        't_peak_mean': df['OUT_t_peak'][mask].mean(),
        'Th17_max_mean': df['Th17_max'][mask].mean(),
        'Treg_max_mean': df['Treg_max'][mask].mean(),
    }
    subtype_rows.append(row)
pd.DataFrame(subtype_rows).to_csv('/workspace/patient_subtypes_pca2.csv', index=False)
print("Saved patient_subtypes_pca2.csv")

# Stability analysis
print("\n=== Stability analysis (PCA(2)) ===")
sils = []
labels_list = []
for seed in range(10):
    km_s = KMeans(n_clusters=3, random_state=seed, n_init=10)
    lab = km_s.fit_predict(X_pca)
    sils.append(silhouette_score(X_pca, lab))
    labels_list.append(lab)

aris = [adjusted_rand_score(labels_list[0], labels_list[i]) for i in range(10)]
print(f"Silhouette: {np.mean(sils):.4f} ± {np.std(sils):.4f}")
print(f"ARI (10 seeds): mean={np.mean(aris):.4f}, min={np.min(aris):.4f}, max={np.max(aris):.4f}")

# Bootstrap
n = len(X_pca)
ref = labels_list[0]
boot_ari = []
for iter_idx in range(100):
    rng = np.random.RandomState(iter_idx * 1000 + 42)
    idx = rng.choice(n, size=int(0.8*n), replace=False)
    X_boot = X_pca[idx]
    km_b = KMeans(n_clusters=3, random_state=0, n_init=10)
    boot_labels = km_b.fit_predict(X_boot)
    boot_ari.append(adjusted_rand_score(ref[idx], boot_labels))
print(f"Bootstrap ARI: {np.mean(boot_ari):.4f} ± {np.std(boot_ari):.4f}")

# K comparison
print("\nK comparison:")
stab_data = []
for K in [2, 3, 4, 5]:
    sils_k = []
    for seed in range(10):
        km_s = KMeans(n_clusters=K, random_state=seed, n_init=10)
        lab = km_s.fit_predict(X_pca)
        sil = silhouette_score(X_pca, lab)
        sils_k.append(sil)
        sizes_k = sorted(np.bincount(lab).tolist(), reverse=True)
        stab_data.append({'K': K, 'Seed': seed, 'Silhouette': sil,
                          'Cluster_sizes': str(sizes_k), 'Min_cluster': min(sizes_k), 'Max_cluster': max(sizes_k)})
    print(f"  K={K}: silhouette = {np.mean(sils_k):.4f}")

pd.DataFrame(stab_data).to_csv('/workspace/pca2_stability_results.csv', index=False)
pd.DataFrame({'Seed': range(10), 'ARI_vs_seed0': aris}).to_csv('/workspace/pca2_ari_between_seeds.csv', index=False)
pd.DataFrame({'Iteration': range(100), 'Bootstrap_ARI': boot_ari}).to_csv('/workspace/pca2_bootstrap_ari.csv', index=False)

summary = {}
for K in [2,3,4,5]:
    sils_k = [s for s in [r['Silhouette'] for r in stab_data if r['K']==K]]
    summary[f'K={K}_avg_silhouette'] = np.mean(sils_k)
summary['K=3_ARI_mean'] = float(np.mean(aris))
summary['K=3_ARI_min'] = float(np.min(aris))
summary['K=3_ARI_max'] = float(np.max(aris))
summary['K=3_bootstrap_ARI_mean'] = float(np.mean(boot_ari))
summary['K=3_bootstrap_ARI_std'] = float(np.std(boot_ari))
pd.DataFrame([summary]).to_csv('/workspace/pca2_stability_summary.csv', index=False)

print("\nAll files saved!")
