"""
SAR AI Multi-Dimensional Prediction
=====================================
1. Virtual cohort generation (2000 patients, lognormal parameter sampling)
2. MLP surrogate model (parameter → symptom prediction, 5-fold CV)
3. Response surface analysis (top-6 sensitive parameter pairs)
4. K-means patient subtyping (PCA + radar charts)

Generates:
  - Fig 9: Surrogate model prediction vs ODE truth (R²)
  - Fig 10: 6 response surface heatmaps (2×3)
  - Fig 11: Clustering results (PCA + subtype radar)
  - sar_virtual_cohort.csv (2000 patients)
"""

import sys
sys.path.insert(0, '/workspace')

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
from scipy.integrate import solve_ivp
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import cross_val_predict, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import r2_score, mean_absolute_error
import warnings
warnings.filterwarnings('ignore')

# Font settings
matplotlib.rcParams['font.family'] = ['Liberation Sans', 'Arimo', 'DejaVu Sans']
matplotlib.rcParams['svg.fonttype'] = 'none'
matplotlib.rcParams['figure.dpi'] = 150

from sar_ode_model_v2 import (
    DEFAULT_PARAMS as P2, DEFAULT_IC as IC2,
    STATE_NAMES as SN2, ode_system_v2
)

FIG_DIR = '/mnt/results/figures'
import os
os.makedirs(FIG_DIR, exist_ok=True)

# Colors
C_BLUE = '#0279EE'
C_ORANGE = '#FF9400'
C_GREEN = '#75A025'
C_PINK = '#FD9BED'
C_RED = '#D62728'
C_PURPLE = '#9467BD'
C_CYAN = '#17BECF'
C_BLACK = '#000000'
C_GRAY = '#7F7F7F'

# ===========================================================================
# 1. Define parameters to vary (exclude fixed constants like Sym_max)
# ===========================================================================
VARY_PARAMS = [
    'k_A', 'k_Al1', 'k_Al2', 'Al_max',
    'k_DC1', 'k_DC2', 'DC_max',
    'k_T1', 'k_T2', 'Th2_max',
    'k_C1', 'k_C2',
    'k_IgE0', 'k_IgE1', 'k_IgE2',
    'k_MC1', 'k_MC2',
    'k_Med1', 'k_Med2',
    'k_Eos1', 'k_Eos2', 'Eos_max',
    'k_S1', 'k_S2', 'k_S5',
    # TLR4 pathway
    'k_TLR1', 'k_TLR2', 'k_MyD1', 'k_MyD2',
    'k_NF1', 'k_NF2', 'k_PI1', 'k_PI2',
    'k_Neu1', 'k_Neu2', 'Neu_max',
    'k_AlNF', 'k_DCNF',
    # Th17/Treg
    'k_Th17_1', 'k_Th17_2', 'Th17_max',
    'k_IL17_1', 'k_IL17_2',
    'k_Treg_1', 'k_Treg_2', 'Treg_max',
    'k_IL10_1', 'k_IL10_2',
    'k_Treg_inh', 'k_Th17_inh',
    'k_T1IL17', 'k_Neu1IL17', 'k_IL10_DC',
    # Symptom contributions
    'k_S3b', 'k_S4', 'k_S_IL10',
]

# Also vary some initial conditions
VARY_IC = ['A', 'IgE', 'Th2', 'Eos', 'Treg', 'Th17']

print(f"Total varying parameters: {len(VARY_PARAMS)} parameters + {len(VARY_IC)} initial conditions = {len(VARY_PARAMS) + len(VARY_IC)} features")

# ===========================================================================
# 2. Generate virtual cohort (2000 patients)
# ===========================================================================
N_PATIENTS = 2000
CV = 0.30  # coefficient of variation

np.random.seed(42)

# Sample parameters from lognormal distribution (ensures positivity)
param_samples = {}
for pname in VARY_PARAMS:
    base_val = P2[pname]
    # Lognormal: mean = base_val, CV = 0.30
    sigma = np.sqrt(np.log(1 + CV**2))
    mu = np.log(base_val) - sigma**2 / 2
    samples = np.random.lognormal(mean=mu, sigma=sigma, size=N_PATIENTS)
    param_samples[pname] = samples

# Sample initial conditions
ic_samples = {}
for icname in VARY_IC:
    base_val = IC2[icname]
    if base_val > 0:
        sigma = np.sqrt(np.log(1 + CV**2))
        mu = np.log(base_val) - sigma**2 / 2
        samples = np.random.lognormal(mean=mu, sigma=sigma, size=N_PATIENTS)
    else:
        samples = np.zeros(N_PATIENTS)
    ic_samples[icname] = samples

print(f"Generated {N_PATIENTS} virtual patients with {len(VARY_PARAMS) + len(VARY_IC)} varying features")

# ===========================================================================
# 3. Solve ODE for each patient (with parallelization)
# ===========================================================================
from joblib import Parallel, delayed
import time

def solve_single_patient(idx):
    """Solve ODE for a single patient."""
    params = P2.copy()
    for pname in VARY_PARAMS:
        params[pname] = param_samples[pname][idx]

    ic = IC2.copy()
    for icname in VARY_IC:
        ic[icname] = ic_samples[icname][idx]

    y0 = np.array([ic[name] for name in SN2])
    t_eval = np.linspace(0, 24, 241)

    try:
        result = solve_ivp(
            fun=lambda t, y: ode_system_v2(t, y, params),
            t_span=(0, 24), y0=y0, t_eval=t_eval,
            method='LSODA', rtol=1e-6, atol=1e-8,
        )
        if not result.success:
            return None

        sym = result.y[9]
        t = result.t

        return {
            'Sym_max': float(np.max(sym)),
            't_peak': float(t[np.argmax(sym)]),
            'AUC': float(np.trapezoid(sym, t)),
            'Eos_peak': float(np.max(result.y[8])),
            'Neu_peak': float(np.max(result.y[14])),
            'IL17_peak': float(np.max(result.y[16])),
            'ProInf_peak': float(np.max(result.y[13])),
            'Th17_peak': float(np.max(result.y[15])),
            'Treg_min': float(np.min(result.y[17])),
            'IL10_peak': float(np.max(result.y[18])),
            'success': True,
        }
    except Exception:
        return None

print(f"\nSolving ODE for {N_PATIENTS} virtual patients (parallel, 4 workers)...")
t_start = time.time()
results = Parallel(n_jobs=4, verbose=5)(
    delayed(solve_single_patient)(i) for i in range(N_PATIENTS)
)
t_elapsed = time.time() - t_start
print(f"Completed in {t_elapsed:.1f}s ({t_elapsed/60:.1f} min)")

# Filter successful results
valid_mask = [r is not None and r['success'] for r in results]
valid_indices = [i for i, v in enumerate(valid_mask) if v]
print(f"Successful: {sum(valid_mask)}/{N_PATIENTS}")

# Build feature matrix and target matrix
feature_names = VARY_PARAMS + [f'IC_{ic}' for ic in VARY_IC]
X = np.array([
    [param_samples[p][i] for p in VARY_PARAMS] +
    [ic_samples[ic][i] for ic in VARY_IC]
    for i in valid_indices
])

# Targets
target_names = ['Sym_max', 'AUC', 'Eos_peak', 'Neu_peak', 'IL17_peak', 't_peak']
Y = np.array([
    [results[i][t] for t in target_names]
    for i in valid_indices
])

# Also collect all output metrics for clustering
all_output_names = ['Sym_max', 't_peak', 'AUC', 'Eos_peak', 'Neu_peak', 'IL17_peak',
                    'ProInf_peak', 'Th17_peak', 'Treg_min', 'IL10_peak']
Y_all = np.array([
    [results[i][t] for t in all_output_names]
    for i in valid_indices
])

print(f"Feature matrix: {X.shape}, Target matrix: {Y.shape}")

# Save virtual cohort
cohort_df = pd.DataFrame(X, columns=feature_names)
for j, tn in enumerate(target_names):
    cohort_df[f'OUT_{tn}'] = Y[:, j]
cohort_df.to_csv('/mnt/results/sar_virtual_cohort.csv', index=False)
print(f"Virtual cohort saved: {cohort_df.shape}")

# ===========================================================================
# 4. MLP Surrogate Model (5-fold cross-validation)
# ===========================================================================
print("\n=== Training MLP Surrogate Model ===")

scaler_X = StandardScaler()
X_scaled = scaler_X.fit_transform(X)

# Train separate MLP for each target
surrogate_results = {}
fig, axes = plt.subplots(2, 3, figsize=(15, 10))
axes = axes.flatten()

for j, target in enumerate(target_names):
    y_target = Y[:, j]

    # MLP architecture
    mlp = MLPRegressor(
        hidden_layer_sizes=(128, 64, 32),
        activation='relu',
        solver='adam',
        max_iter=500,
        learning_rate='adaptive',
        random_state=42,
        early_stopping=True,
        validation_fraction=0.15,
    )

    # 5-fold CV predictions
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    y_pred = cross_val_predict(mlp, X_scaled, y_target, cv=kf)

    r2 = r2_score(y_target, y_pred)
    mae = mean_absolute_error(y_target, y_pred)
    surrogate_results[target] = {'R2': r2, 'MAE': mae}

    # Plot
    ax = axes[j]
    ax.scatter(y_target, y_pred, alpha=0.3, s=8, color=C_BLUE)
    lims = [min(y_target.min(), y_pred.min()), max(y_target.max(), y_pred.max())]
    ax.plot(lims, lims, color=C_RED, linewidth=1.5, linestyle='--')
    ax.set_xlabel(f'ODE Truth', fontsize=10)
    ax.set_ylabel('MLP Prediction', fontsize=10)
    ax.set_title(f'{target}\nR²={r2:.3f}, MAE={mae:.3f}', fontsize=11, fontweight='bold')
    ax.set_xlim(lims)
    ax.set_ylim(lims)

plt.suptitle('MLP Surrogate Model: Prediction vs ODE Truth (5-fold CV, n=2000)', fontsize=14, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig(f'{FIG_DIR}/fig9_surrogate_model.png', dpi=300, bbox_inches='tight')
plt.savefig(f'{FIG_DIR}/fig9_surrogate_model.svg', bbox_inches='tight')
plt.close()
print("Fig 9 saved.")

print("\nSurrogate model performance:")
for target, metrics in surrogate_results.items():
    print(f"  {target}: R²={metrics['R2']:.4f}, MAE={metrics['MAE']:.4f}")

# ===========================================================================
# 5. Feature importance (via permutation on best model - Sym_max)
# ===========================================================================
print("\n=== Feature Importance Analysis ===")

# Train final model on all data for Sym_max
mlp_final = MLPRegressor(
    hidden_layer_sizes=(128, 64, 32), activation='relu', solver='adam',
    max_iter=500, learning_rate='adaptive', random_state=42,
    early_stopping=True, validation_fraction=0.15,
)
mlp_final.fit(X_scaled, Y[:, 0])  # Sym_max

# Permutation importance
from sklearn.inspection import permutation_importance
perm_imp = permutation_importance(mlp_final, X_scaled, Y[:, 0],
                                   n_repeats=10, random_state=42, scoring='r2')
importance_df = pd.DataFrame({
    'feature': feature_names,
    'importance_mean': perm_imp.importances_mean,
    'importance_std': perm_imp.importances_std,
}).sort_values('importance_mean', ascending=False)

print("Top-15 most important features for Sym_max:")
print(importance_df.head(15).to_string(index=False))

# ===========================================================================
# 6. Response Surface Analysis (top-6 parameter pairs)
# ===========================================================================
print("\n=== Response Surface Analysis ===")

# Select top-6 most important parameters
top6_params = importance_df.head(6)['feature'].values.tolist()
print(f"Top-6 parameters: {top6_params}")

# Generate 3 pairs: (1,2), (3,4), (5,6)
pairs = [(0,1), (2,3), (4,5)]

fig, axes = plt.subplots(1, 3, figsize=(18, 5.5))

for pidx, (i, j) in enumerate(pairs):
    p1_name = top6_params[i]
    p2_name = top6_params[j]

    # Get base values
    if p1_name.startswith('IC_'):
        base1 = IC2[p1_name.replace('IC_', '')]
    else:
        base1 = P2[p1_name]
    if p2_name.startswith('IC_'):
        base2 = IC2[p2_name.replace('IC_', '')]
    else:
        base2 = P2[p2_name]

    # Grid: 30x30, range = 0.5x to 2x base value
    n_grid = 30
    p1_range = np.linspace(base1 * 0.3, base1 * 2.0, n_grid)
    p2_range = np.linspace(base2 * 0.3, base2 * 2.0, n_grid)
    P1_grid, P2_grid = np.meshgrid(p1_range, p2_range)

    # Predict using surrogate model
    X_grid = np.zeros((n_grid * n_grid, len(feature_names)))
    # Fill with mean values
    X_mean = X.mean(axis=0)
    X_grid[:] = X_mean

    # Set varying parameters
    idx1 = feature_names.index(p1_name)
    idx2 = feature_names.index(p2_name)
    X_grid[:, idx1] = P1_grid.ravel()
    X_grid[:, idx2] = P2_grid.ravel()

    X_grid_scaled = scaler_X.transform(X_grid)
    Sym_pred = mlp_final.predict(X_grid_scaled).reshape(n_grid, n_grid)

    # Plot heatmap
    ax = axes[pidx]
    im = ax.pcolormesh(P1_grid, P2_grid, Sym_pred, cmap='RdYlBu_r', shading='auto')
    ax.set_xlabel(p1_name, fontsize=11)
    ax.set_ylabel(p2_name, fontsize=11)
    ax.set_title(f'{p1_name} × {p2_name}', fontsize=12, fontweight='bold')
    plt.colorbar(im, ax=ax, label='Predicted Sym_max')

plt.suptitle('Response Surface Analysis: Sym_max vs Top Parameter Pairs', fontsize=14, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig(f'{FIG_DIR}/fig10_response_surfaces.png', dpi=300, bbox_inches='tight')
plt.savefig(f'{FIG_DIR}/fig10_response_surfaces.svg', bbox_inches='tight')
plt.close()
print("Fig 10 saved.")

# ===========================================================================
# 7. K-means Patient Subtyping
# ===========================================================================
print("\n=== K-means Patient Subtyping ===")

# Use output features for clustering
cluster_features = ['Sym_max', 'AUC', 'Eos_peak', 'Neu_peak', 'IL17_peak', 't_peak']
Y_cluster = Y.copy()

# Standardize
scaler_Y = StandardScaler()
Y_cluster_scaled = scaler_Y.fit_transform(Y_cluster)

# Determine optimal K using elbow + silhouette
from sklearn.metrics import silhouette_score
k_range = range(2, 8)
silhouettes = []
for k in k_range:
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = km.fit_predict(Y_cluster_scaled)
    sil = silhouette_score(Y_cluster_scaled, labels)
    silhouettes.append(sil)
    print(f"  K={k}: silhouette={sil:.4f}")

best_k = list(k_range)[np.argmax(silhouettes)]
print(f"Best K={best_k} (silhouette={max(silhouettes):.4f})")

# Use K=4 for clinical interpretability (or best_k if it's 3-4)
k_final = best_k if 3 <= best_k <= 4 else 4
print(f"Using K={k_final} for clustering")

km_final = KMeans(n_clusters=k_final, random_state=42, n_init=10)
cluster_labels = km_final.fit_predict(Y_cluster_scaled)

# PCA for visualization
pca = PCA(n_components=2)
Y_pca = pca.fit_transform(Y_cluster_scaled)
print(f"PCA explained variance: PC1={pca.explained_variance_ratio_[0]:.3f}, PC2={pca.explained_variance_ratio_[1]:.3f}")

# ===========================================================================
# FIGURE 11: Clustering results (PCA + radar)
# ===========================================================================
fig = plt.figure(figsize=(16, 6))

# Panel A: PCA scatter
ax1 = fig.add_subplot(1, 2, 1)
cluster_colors = [C_BLUE, C_RED, C_GREEN, C_ORANGE, C_PURPLE][:k_final]
cluster_names = []
for k in range(k_final):
    mask = cluster_labels == k
    ax1.scatter(Y_pca[mask, 0], Y_pca[mask, 1], c=cluster_colors[k], alpha=0.4, s=10, label=f'Subtype {k+1}')
    cluster_names.append(f'Subtype {k+1}')

# Mark centroids
centroids_pca = pca.transform(km_final.cluster_centers_)
ax1.scatter(centroids_pca[:, 0], centroids_pca[:, 1], c=cluster_colors, marker='X', s=200, edgecolors='black', linewidth=1.5, zorder=5)

ax1.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}%)', fontsize=12)
ax1.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}%)', fontsize=12)
ax1.set_title('A. Patient Subtypes (PCA Projection)', fontsize=13, fontweight='bold')
ax1.legend(fontsize=10)

# Panel B: Radar chart of subtype characteristics
ax2 = fig.add_subplot(1, 2, 2, polar=True)

# Compute mean features per cluster
angles = np.linspace(0, 2 * np.pi, len(cluster_features), endpoint=False).tolist()
angles += angles[:1]

for k in range(k_final):
    mask = cluster_labels == k
    mean_vals = Y_cluster[mask].mean(axis=0)
    # Normalize to 0-1 for radar
    val_min = Y_cluster.min(axis=0)
    val_max = Y_cluster.max(axis=0)
    norm_vals = (mean_vals - val_min) / (val_max - val_min + 1e-10)
    vals = norm_vals.tolist() + [norm_vals[0]]
    ax2.plot(angles, vals, color=cluster_colors[k], linewidth=2, label=f'Subtype {k+1} (n={mask.sum()})')
    ax2.fill(angles, vals, color=cluster_colors[k], alpha=0.15)

ax2.set_xticks(angles[:-1])
ax2.set_xticklabels(cluster_features, fontsize=9)
ax2.set_title('B. Subtype Characteristics (Normalized)', fontsize=13, fontweight='bold', pad=20)
ax2.legend(fontsize=9, loc='upper right', bbox_to_anchor=(1.3, 1.1))

plt.suptitle(f'Patient Subtyping: K-means Clustering (K={k_final}, n={len(valid_indices)})', fontsize=14, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig(f'{FIG_DIR}/fig11_patient_subtypes.png', dpi=300, bbox_inches='tight')
plt.savefig(f'{FIG_DIR}/fig11_patient_subtypes.svg', bbox_inches='tight')
plt.close()
print("Fig 11 saved.")

# ===========================================================================
# Subtype summary table
# ===========================================================================
subtype_summary = []
for k in range(k_final):
    mask = cluster_labels == k
    row = {'Subtype': f'Subtype {k+1}', 'N': int(mask.sum())}
    for j, feat in enumerate(cluster_features):
        row[f'{feat}_mean'] = float(Y_cluster[mask, j].mean())
        row[f'{feat}_std'] = float(Y_cluster[mask, j].std())
    subtype_summary.append(row)

subtype_df = pd.DataFrame(subtype_summary)
subtype_df.to_csv('/mnt/results/patient_subtypes.csv', index=False)
print("\nPatient subtype summary:")
print(subtype_df.to_string(index=False))

# Save surrogate model performance
surrogate_df = pd.DataFrame([
    {'Target': t, 'R2': m['R2'], 'MAE': m['MAE']}
    for t, m in surrogate_results.items()
])
surrogate_df.to_csv('/mnt/results/surrogate_model_performance.csv', index=False)

# Save feature importance
importance_df.to_csv('/mnt/results/feature_importance.csv', index=False)

print("\n=== AI prediction analysis complete ===")
print(f"Total elapsed: {time.time() - t_start:.1f}s")
