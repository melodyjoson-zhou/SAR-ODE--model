"""
SAR Model Comparison: 10-dim vs 19-dim
========================================
Generates:
  - Fig 5: Symptom curve overlay comparison
  - Fig 6: New pathway 9-variable time course (3 panels)
  - Fig 7: Pathway contribution decomposition (stacked)
  - Fig 8: 8-drug intervention comparison (4 original + 4 new)
  - Table 4: Core metrics comparison
  - Table 5: Sensitivity analysis comparison
"""

import sys
sys.path.insert(0, '/workspace')

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import pandas as pd
from scipy.integrate import solve_ivp

# Font settings
matplotlib.rcParams['font.family'] = ['Liberation Sans', 'Arimo', 'DejaVu Sans']
matplotlib.rcParams['svg.fonttype'] = 'none'
matplotlib.rcParams['figure.dpi'] = 150

from sar_ode_model import (
    solve_model as solve_v1, compute_metrics as metrics_v1,
    result_to_dataframe as df_v1, DEFAULT_PARAMS as P1, DEFAULT_IC as IC1,
    STATE_NAMES as SN1, ode_system as ode_v1
)
from sar_ode_model_v2 import (
    solve_model_v2 as solve_v2, compute_metrics_v2 as metrics_v2,
    result_to_dataframe_v2 as df_v2, DEFAULT_PARAMS as P2, DEFAULT_IC as IC2,
    STATE_NAMES as SN2, ode_system_v2 as ode_v2,
    DRUG_INTERVENTIONS_V2, solve_with_intervention_v2
)

FIG_DIR = '/mnt/results/figures'
import os
os.makedirs(FIG_DIR, exist_ok=True)

# Colorblind-friendly palette
C_BLUE = '#0279EE'
C_ORANGE = '#FF9400'
C_GREEN = '#75A025'
C_PINK = '#FD9BED'
C_YELLOW = '#E9ED4C'
C_BLACK = '#000000'
C_RED = '#D62728'
C_PURPLE = '#9467BD'
C_CYAN = '#17BECF'
C_BROWN = '#8C564B'
C_GRAY = '#7F7F7F'

# ===========================================================================
# Solve both models
# ===========================================================================
res1 = solve_v1()
res2 = solve_v2()
df1 = df_v1(res1)
df2 = df_v2(res2)
m1 = metrics_v1(res1)
m2 = metrics_v2(res2)

print("=== 10-dim model metrics ===")
for k, v in m1.items():
    print(f"  {k}: {v:.3f}")
print("=== 19-dim model metrics ===")
for k, v in m2.items():
    print(f"  {k}: {v:.3f}")

# ===========================================================================
# FIGURE 5: Symptom curve overlay comparison
# ===========================================================================
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# Panel A: Symptom curves
ax = axes[0]
ax.plot(df1['time_h'], df1['Sym'], color=C_BLUE, linewidth=2.5, label='10-dim (core axis)')
ax.plot(df2['time_h'], df2['Sym'], color=C_RED, linewidth=2.5, linestyle='--', label='19-dim (+TLR4 +Th17/Treg)')
ax.axvline(x=2, color=C_GRAY, linestyle=':', alpha=0.5)
ax.axvline(x=6, color=C_GRAY, linestyle=':', alpha=0.5)
ax.set_xlabel('Time (h)', fontsize=12)
ax.set_ylabel('Symptom Score (0-10)', fontsize=12)
ax.set_title('A. Symptom Time Course Comparison', fontsize=13, fontweight='bold')
ax.legend(fontsize=10, loc='upper right')
ax.set_xlim(0, 24)
ax.set_ylim(0, 8)
ax.text(1, 7.3, 'Immediate\nphase', ha='center', fontsize=9, color=C_GRAY)
ax.text(9, 4.5, 'Late phase', ha='center', fontsize=9, color=C_GRAY)

# Annotate peaks
ax.annotate(f'Peak: {m1["Sym_max"]:.1f}', xy=(m1['t_peak_h'], m1['Sym_max']),
            xytext=(4, 7.5), fontsize=9, color=C_BLUE,
            arrowprops=dict(arrowstyle='->', color=C_BLUE, lw=1.2))
ax.annotate(f'Peak: {m2["Sym_max"]:.1f}', xy=(m2['t_peak_h'], m2['Sym_max']),
            xytext=(4, 6.8), fontsize=9, color=C_RED,
            arrowprops=dict(arrowstyle='->', color=C_RED, lw=1.2))

# Panel B: Difference plot
ax = axes[1]
diff = df2['Sym'].values - df1['Sym'].values
ax.fill_between(df1['time_h'], diff, 0, where=(diff >= 0), color=C_RED, alpha=0.3, label='19-dim higher')
ax.fill_between(df1['time_h'], diff, 0, where=(diff < 0), color=C_BLUE, alpha=0.3, label='19-dim lower')
ax.plot(df1['time_h'], diff, color=C_BLACK, linewidth=1.5)
ax.axhline(y=0, color=C_GRAY, linestyle='-', linewidth=0.8)
ax.set_xlabel('Time (h)', fontsize=12)
ax.set_ylabel('Symptom Difference (19-dim - 10-dim)', fontsize=12)
ax.set_title('B. Prediction Difference', fontsize=13, fontweight='bold')
ax.legend(fontsize=10)
ax.set_xlim(0, 24)

plt.tight_layout()
plt.savefig(f'{FIG_DIR}/fig5_model_comparison.png', dpi=300, bbox_inches='tight')
plt.savefig(f'{FIG_DIR}/fig5_model_comparison.svg', bbox_inches='tight')
plt.close()
print("Fig 5 saved.")

# ===========================================================================
# FIGURE 6: New pathway 9-variable time course (3 panels)
# ===========================================================================
fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# Panel A: TLR4/MyD88/NF-κB cascade
ax = axes[0, 0]
ax2 = ax.twinx()
ax.plot(df2['time_h'], df2['TLR4'], color=C_BLUE, linewidth=2, label='TLR4')
ax.plot(df2['time_h'], df2['MyD88'], color=C_ORANGE, linewidth=2, label='MyD88')
ax.plot(df2['time_h'], df2['NFkB'], color=C_GREEN, linewidth=2, label='NF-κB')
ax2.plot(df2['time_h'], df2['ProInf'], color=C_RED, linewidth=2, linestyle='--', label='Pro-inf. cytokines')
ax.set_xlabel('Time (h)', fontsize=11)
ax.set_ylabel('Activation (fraction 0-1)', fontsize=11)
ax2.set_ylabel('Pro-inflammatory (pg/mL)', fontsize=11, color=C_RED)
ax.set_title('A. TLR4/MyD88/NF-κB Cascade', fontsize=12, fontweight='bold')
ax.set_xlim(0, 24)
lines1, labels1 = ax.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax.legend(lines1 + lines2, labels1 + labels2, fontsize=9, loc='upper right')

# Panel B: Th17/Treg dynamics
ax = axes[0, 1]
ax2 = ax.twinx()
ax.plot(df2['time_h'], df2['Th17'], color=C_RED, linewidth=2, label='Th17')
ax.plot(df2['time_h'], df2['Treg'], color=C_BLUE, linewidth=2, label='Treg')
ax2.plot(df2['time_h'], df2['IL17'], color=C_ORANGE, linewidth=2, linestyle='--', label='IL-17')
ax2.plot(df2['time_h'], df2['IL10'], color=C_GREEN, linewidth=2, linestyle=':', label='IL-10')
ax.set_xlabel('Time (h)', fontsize=11)
ax.set_ylabel('Cells (cells/μL)', fontsize=11)
ax2.set_ylabel('Cytokines (pg/mL)', fontsize=11)
ax.set_title('B. Th17/Treg Imbalance Axis', fontsize=12, fontweight='bold')
ax.set_xlim(0, 24)
lines1, labels1 = ax.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax.legend(lines1 + lines2, labels1 + labels2, fontsize=9, loc='center right')

# Panel C: Neutrophils and cross-talk effects
ax = axes[1, 0]
ax.plot(df2['time_h'], df2['Neu'], color=C_PURPLE, linewidth=2, label='Neutrophils')
ax.set_xlabel('Time (h)', fontsize=11)
ax.set_ylabel('Neutrophils (cells/μL)', fontsize=11)
ax.set_title('C. Neutrophil Recruitment', fontsize=12, fontweight='bold')
ax.set_xlim(0, 24)
ax.legend(fontsize=10)

# Panel D: Th17/Treg ratio
ax = axes[1, 1]
ratio = df2['Th17'] / df2['Treg']
ax.plot(df2['time_h'], ratio, color=C_RED, linewidth=2.5)
ax.axhline(y=1.0, color=C_GRAY, linestyle=':', alpha=0.5, label='Balance (ratio=1)')
ax.set_xlabel('Time (h)', fontsize=11)
ax.set_ylabel('Th17/Treg Ratio', fontsize=11)
ax.set_title('D. Th17/Treg Ratio (Imbalance Index)', fontsize=12, fontweight='bold')
ax.set_xlim(0, 24)
ax.legend(fontsize=10)

plt.tight_layout()
plt.savefig(f'{FIG_DIR}/fig6_new_pathways_timecourse.png', dpi=300, bbox_inches='tight')
plt.savefig(f'{FIG_DIR}/fig6_new_pathways_timecourse.svg', bbox_inches='tight')
plt.close()
print("Fig 6 saved.")

# ===========================================================================
# FIGURE 7: Pathway contribution decomposition (stacked area)
# ===========================================================================
fig, ax = plt.subplots(figsize=(10, 6))

# Compute individual contributions to symptom generation rate
t = df2['time_h'].values
contrib_med = P2['k_S1'] * df2['Med'].values * (1 - df2['Sym'].values / P2['Sym_max'])
contrib_eos = P2['k_S2'] * df2['Eos'].values * (1 - df2['Sym'].values / P2['Sym_max'])
contrib_neu = P2['k_S3b'] * df2['Neu'].values * (1 - df2['Sym'].values / P2['Sym_max'])
contrib_proinf = P2['k_S4'] * df2['ProInf'].values * (1 - df2['Sym'].values / P2['Sym_max'])
contrib_il10 = -P2['k_S_IL10'] * df2['IL10'].values  # negative (suppression)

ax.stackplot(t, contrib_med, contrib_eos, contrib_neu, contrib_proinf,
             labels=['Mediators (histamine/LT)', 'Eosinophils', 'Neutrophils', 'Pro-inf. cytokines'],
             colors=[C_ORANGE, C_PINK, C_PURPLE, C_RED], alpha=0.7)
ax.plot(t, contrib_il10, color=C_GREEN, linewidth=2, linestyle='--', label='IL-10 suppression')
ax.axhline(y=0, color=C_BLACK, linewidth=0.8)
ax.set_xlabel('Time (h)', fontsize=12)
ax.set_ylabel('Symptom Generation Rate (score/h)', fontsize=12)
ax.set_title('Pathway Contribution to Symptom Generation', fontsize=13, fontweight='bold')
ax.legend(fontsize=9, loc='upper right')
ax.set_xlim(0, 24)

plt.tight_layout()
plt.savefig(f'{FIG_DIR}/fig7_pathway_contribution.png', dpi=300, bbox_inches='tight')
plt.savefig(f'{FIG_DIR}/fig7_pathway_contribution.svg', bbox_inches='tight')
plt.close()
print("Fig 7 saved.")

# ===========================================================================
# FIGURE 8: 8-drug intervention comparison
# ===========================================================================
drug_names = list(DRUG_INTERVENTIONS_V2.keys())
drug_results = {}
drug_metrics = {}

for name in drug_names:
    res = solve_with_intervention_v2(name)
    drug_results[name] = df_v2(res)
    drug_metrics[name] = metrics_v2(res)

fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# Panel A: Symptom curves
ax = axes[0]
colors = [C_BLACK, C_BLUE, C_GREEN, C_ORANGE, C_PINK, C_RED, C_PURPLE, C_CYAN, C_BROWN]
for i, name in enumerate(drug_names):
    ls = '-' if i == 0 else '--'
    lw = 2.5 if i == 0 else 1.5
    ax.plot(drug_results[name]['time_h'], drug_results[name]['Sym'],
            color=colors[i], linewidth=lw, linestyle=ls, label=name, alpha=0.85)
ax.set_xlabel('Time (h)', fontsize=12)
ax.set_ylabel('Symptom Score (0-10)', fontsize=12)
ax.set_title('A. Drug Intervention Symptom Curves', fontsize=13, fontweight='bold')
ax.legend(fontsize=8, loc='upper right', ncol=2)
ax.set_xlim(0, 24)
ax.set_ylim(0, 8)

# Panel B: AUC reduction bar chart
ax = axes[1]
ctrl_auc = drug_metrics['Control']['AUC_0_24h']
drug_labels = drug_names[1:]  # exclude control
auc_reductions = []
peak_reductions = []
ctrl_peak = drug_metrics['Control']['Sym_max']
for name in drug_labels:
    auc_red = (1 - drug_metrics[name]['AUC_0_24h'] / ctrl_auc) * 100
    peak_red = (1 - drug_metrics[name]['Sym_max'] / ctrl_peak) * 100
    auc_reductions.append(auc_red)
    peak_reductions.append(peak_red)

x = np.arange(len(drug_labels))
width = 0.35
bars1 = ax.bar(x - width/2, auc_reductions, width, color=C_BLUE, label='AUC reduction (%)', alpha=0.8)
bars2 = ax.bar(x + width/2, peak_reductions, width, color=C_ORANGE, label='Peak reduction (%)', alpha=0.8)
ax.set_ylabel('Reduction (%)', fontsize=12)
ax.set_title('B. Drug Efficacy Comparison', fontsize=13, fontweight='bold')
ax.set_xticks(x)
ax.set_xticklabels([d.split('(')[0].strip() for d in drug_labels], rotation=35, ha='right', fontsize=9)
ax.legend(fontsize=10)
ax.axhline(y=0, color=C_BLACK, linewidth=0.5)

# Add value labels
for bar in bars1:
    h = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2., h + 0.5, f'{h:.1f}%',
            ha='center', va='bottom', fontsize=7)
for bar in bars2:
    h = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2., h + 0.5, f'{h:.1f}%',
            ha='center', va='bottom', fontsize=7)

plt.tight_layout()
plt.savefig(f'{FIG_DIR}/fig8_drug_intervention_v2.png', dpi=300, bbox_inches='tight')
plt.savefig(f'{FIG_DIR}/fig8_drug_intervention_v2.svg', bbox_inches='tight')
plt.close()
print("Fig 8 saved.")

# ===========================================================================
# TABLE 4: Core metrics comparison
# ===========================================================================
table4 = pd.DataFrame({
    'Metric': ['Sym_max', 't_peak (h)', 'AUC_0_24h', 'Eos_peak', 'Neu_peak',
               'IL17_peak', 'ProInf_peak', 'Th17_peak', 'Treg_min',
               'Immediate phase (0-2h AUC)', 'Late phase (6-24h AUC)'],
    '10-dim model': [
        f"{m1['Sym_max']:.2f}", f"{m1['t_peak_h']:.2f}", f"{m1['AUC_0_24h']:.2f}",
        f"{m1.get('Eos_peak', np.max(res1.y[8])):.2f}", 'N/A', 'N/A', 'N/A', 'N/A', 'N/A',
        f"{np.trapz(res1.y[9][res1.t <= 2], res1.t[res1.t <= 2]):.2f}",
        f"{np.trapz(res1.y[9][res1.t >= 6], res1.t[res1.t >= 6]):.2f}",
    ],
    '19-dim model': [
        f"{m2['Sym_max']:.2f}", f"{m2['t_peak_h']:.2f}", f"{m2['AUC_0_24h']:.2f}",
        f"{m2['Eos_peak']:.2f}", f"{m2['Neu_peak']:.2f}", f"{m2['IL17_peak']:.2f}",
        f"{m2['ProInf_peak']:.2f}", f"{m2['Th17_peak']:.2f}", f"{m2['Treg_min']:.2f}",
        f"{np.trapz(res2.y[9][res2.t <= 2], res2.t[res2.t <= 2]):.2f}",
        f"{np.trapz(res2.y[9][res2.t >= 6], res2.t[res2.t >= 6]):.2f}",
    ],
})
table4.to_csv('/mnt/results/table4_metrics_comparison.csv', index=False)
print("\nTable 4: Core Metrics Comparison")
print(table4.to_string(index=False))

# ===========================================================================
# TABLE 5: Sensitivity analysis comparison
# ===========================================================================
def sensitivity_analysis(model_func, params, ic, state_names, param_names, delta=0.1):
    """One-at-a-time sensitivity: ±10% perturbation, measure AUC and Sym_max change."""
    base_res = model_func(params=params, ic=ic)
    base_sym = base_res.y[9]
    base_auc = np.trapz(base_sym, base_res.t)
    base_peak = np.max(base_sym)

    results = []
    for pname in param_names:
        for direction in [+1, -1]:
            p_test = params.copy()
            p_test[pname] = params[pname] * (1 + direction * delta)
            try:
                res = model_func(params=p_test, ic=ic)
                sym = res.y[9]
                auc = np.trapz(sym, res.t)
                peak = np.max(sym)
                sens_auc = (auc - base_auc) / base_auc * 100
                sens_peak = (peak - base_peak) / base_peak * 100
                results.append({
                    'parameter': pname,
                    'direction': '+' if direction > 0 else '-',
                    'sens_AUC_%': sens_auc,
                    'sens_peak_%': sens_peak,
                })
            except Exception:
                pass

    df = pd.DataFrame(results)
    # Aggregate: max absolute sensitivity
    agg = df.groupby('parameter').agg(
        sens_AUC_max=('sens_AUC_%', lambda x: max(abs(x))),
        sens_peak_max=('sens_peak_%', lambda x: max(abs(x))),
    ).reset_index()
    agg['sens_combined'] = (agg['sens_AUC_max'] + agg['sens_peak_max']) / 2
    agg = agg.sort_values('sens_combined', ascending=False)
    return agg

# V1 sensitivity
v1_params = P1.copy()
v1_ic = IC1.copy()
v1_param_names = list(P1.keys())
print("\nRunning v1 sensitivity analysis...")
sens_v1 = sensitivity_analysis(solve_v1, v1_params, v1_ic, SN1, v1_param_names)

# V2 sensitivity
v2_params = P2.copy()
v2_ic = IC2.copy()
v2_param_names = list(P2.keys())
print("Running v2 sensitivity analysis...")
sens_v2 = sensitivity_analysis(solve_v2, v2_params, v2_ic, SN2, v2_param_names)

# Save
sens_v1.to_csv('/mnt/results/sar_sensitivity_v1.csv', index=False)
sens_v2.to_csv('/mnt/results/sar_sensitivity_v2.csv', index=False)

# Table 5: Top-10 comparison
top10_v1 = sens_v1.head(10)[['parameter', 'sens_AUC_max', 'sens_peak_max', 'sens_combined']]
top10_v1.columns = ['Parameter (10-dim)', 'Sens AUC %', 'Sens Peak %', 'Combined']
top10_v2 = sens_v2.head(10)[['parameter', 'sens_AUC_max', 'sens_peak_max', 'sens_combined']]
top10_v2.columns = ['Parameter (19-dim)', 'Sens AUC %', 'Sens Peak %', 'Combined']

table5 = pd.concat([top10_v1.reset_index(drop=True), top10_v2.reset_index(drop=True)], axis=1)
table5.to_csv('/mnt/results/table5_sensitivity_comparison.csv', index=False)
print("\nTable 5: Sensitivity Analysis Comparison (Top-10)")
print(table5.to_string(index=False))

# Save drug metrics
drug_df = pd.DataFrame([
    {'Drug': name, 'Sym_max': drug_metrics[name]['Sym_max'],
     't_peak': drug_metrics[name]['t_peak_h'],
     'AUC': drug_metrics[name]['AUC_0_24h'],
     'AUC_reduction_%': (1 - drug_metrics[name]['AUC_0_24h'] / ctrl_auc) * 100,
     'Peak_reduction_%': (1 - drug_metrics[name]['Sym_max'] / ctrl_peak) * 100}
    for name in drug_names
])
drug_df.to_csv('/mnt/results/drug_intervention_v2_results.csv', index=False)
print("\nDrug intervention results saved.")

print("\n=== Comparison analysis complete ===")
